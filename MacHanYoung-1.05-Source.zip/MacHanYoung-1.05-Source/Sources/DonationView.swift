import AppKit

/// Optional support information. This view never changes keyboard preferences.
final class DonationView: NSBox {
    init() {
        super.init(frame: .zero)
        boxType = .custom; titlePosition = .noTitle
        borderWidth = 1; cornerRadius = 12
        borderColor = NSColor(srgbRed: 0.91, green: 0.82, blue: 0.56, alpha: 1)
        fillColor = NSColor(srgbRed: 1, green: 0.98, blue: 0.91, alpha: 1)
        contentViewMargins = .zero
        translatesAutoresizingMaskIntoConstraints = false
        setAccessibilityLabel("카카오페이 후원 안내")

        let column = NSStackView(); column.orientation = .vertical
        column.alignment = .leading; column.spacing = 14
        column.translatesAutoresizingMaskIntoConstraints = false
        let content = contentView!; content.addSubview(column)
        NSLayoutConstraint.activate([
            column.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 18),
            column.trailingAnchor.constraint(equalTo: content.trailingAnchor, constant: -18),
            column.topAnchor.constraint(equalTo: content.topAnchor, constant: 18),
            column.bottomAnchor.constraint(equalTo: content.bottomAnchor, constant: -18)
        ])

        func label(_ text: String, size: CGFloat = 12, color: NSColor = SettingsTheme.ink, weight: NSFont.Weight = .regular) -> NSTextField {
            let label = NSTextField(wrappingLabelWithString: text)
            label.font = .systemFont(ofSize: size, weight: weight); label.textColor = color
            label.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
            return label
        }
        func fullWidth(_ view: NSView, in stack: NSStackView) {
            stack.addArrangedSubview(view)
            view.widthAnchor.constraint(equalTo: stack.widthAnchor).isActive = true
        }
        fullWidth(label("카카오페이 후원", size: 11, color: SettingsTheme.green, weight: .semibold), in: column)
        fullWidth(label("한글을 위한 다음 개발을 응원해 주세요.", size: 16, color: SettingsTheme.green, weight: .semibold), in: column)

        let row = NSStackView(); row.orientation = .horizontal; row.alignment = .top; row.spacing = 18
        fullWidth(row, in: column)
        let message = NSStackView(); message.orientation = .vertical; message.alignment = .leading; message.spacing = 10
        message.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        row.addArrangedSubview(message)
        for text in [
            "우리에게 필요한 한글 도구와 한글을 더 편리하게 사용할 수 있는 프로그램을 만들고 있습니다.",
            "한글 중심의 프로젝트는 해외 후원을 받기 어려워 여러분의 응원이 더욱 소중합니다.",
            "작은 후원이 더 편리한 프로그램을 꾸준히 만드는 힘이 됩니다."
        ] { fullWidth(label(text), in: message) }
        let link = NSButton(title: "사과공방 홈페이지", target: self, action: #selector(openHomepage))
        link.bezelStyle = .inline; link.isBordered = false; link.alignment = .left
        link.attributedTitle = NSAttributedString(string: link.title, attributes: [
            .foregroundColor: SettingsTheme.green, .underlineStyle: NSUnderlineStyle.single.rawValue,
            .font: NSFont.systemFont(ofSize: 12)
        ])
        link.toolTip = "https://applecraft.kr/"
        message.addArrangedSubview(link)

        let qrColumn = NSStackView(); qrColumn.orientation = .vertical; qrColumn.alignment = .centerX; qrColumn.spacing = 6
        qrColumn.widthAnchor.constraint(equalToConstant: 144).isActive = true
        row.addArrangedSubview(qrColumn)
        let image = NSImageView(); image.imageScaling = .scaleProportionallyUpOrDown
        if let url = Bundle.main.url(forResource: "KakaoPayQR", withExtension: "png") { image.image = NSImage(contentsOf: url) }
        image.setAccessibilityLabel("사과공방 카카오페이 후원 QR 코드. 스마트폰 카메라로 스캔하세요.")
        qrColumn.addArrangedSubview(image)
        NSLayoutConstraint.activate([image.widthAnchor.constraint(equalToConstant: 144), image.heightAnchor.constraint(equalToConstant: 144)])
        let caption = label("카카오페이 후원", size: 11); caption.alignment = .center
        fullWidth(caption, in: qrColumn)
        let scan = label("스마트폰으로 스캔해 주세요.", size: 10, color: SettingsTheme.secondary); scan.alignment = .center
        fullWidth(scan, in: qrColumn)

        let line = NSBox(); line.boxType = .separator
        fullWidth(line, in: column)
        let note = label("후원은 자유로운 선택이며, 후원 여부와 관계없이 모든 기능을 무료로 사용할 수 있습니다.", size: 11, color: SettingsTheme.secondary)
        note.alignment = .center; fullWidth(note, in: column)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    @objc private func openHomepage() { NSWorkspace.shared.open(URL(string: "https://applecraft.kr/")!) }
}

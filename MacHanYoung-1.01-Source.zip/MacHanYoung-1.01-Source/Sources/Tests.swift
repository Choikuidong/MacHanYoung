import AppKit
import Carbon
func runTests() throws {
    var count = 0
    func check(_ value: Bool, _ text: String) { count += 1; if !value { fatalError("FAIL: \(text)") } }
    let p = Preferences()
    let base: UInt64 = 0x700000000
    let full = NativeMappings.desired(p, inputReady: true)
    check(full.first { $0.source == base | 0xE2 }?.destination == base | 0xE3, "Alt to Command")
    check(full.first { $0.source == base | 0xE3 }?.destination == base | 0xE2, "Windows to Option")
    check(full.first { $0.source == base | 0xE4 }?.destination == base | 0x6C, "right Ctrl Hanja overrides control mapping")
    check(full.first { $0.source == base | 0x90 }?.destination == base | 0x6F, "dedicated Hangul key")
    check(p.startAtLogin, "automatic login enabled by default")
    let noPermission = NativeMappings.desired(p, inputReady: false)
    check(!noPermission.contains { [base|0x6C,base|0x6D,base|0x6E,base|0x6F].contains($0.destination) }, "no dead sentinel keys without permission")
    var off = p; off.rightControlHanja = false
    check(NativeMappings.desired(off, inputReady: true).first { $0.source == base | 0xE4 }?.destination == base | 0x6E, "right Ctrl retains shortcuts when switch off")
    off.enabled = false; check(NativeMappings.desired(off, inputReady: true).isEmpty, "pause removes native mappings")
    let existing = [KeyMapping(source: base|4, destination: base|5),KeyMapping(source: base|0xE2,destination: base|0xE0)]
    let merged = NativeMappings.merged(original: existing, owned: full)
    check(merged.contains(existing[0]), "unrelated mapping preserved")
    check(merged.filter { $0.source == base|0xE2 }.count == 1, "no duplicate source")
    var t = InputTransformer(); t.controls.insert(79)
    for code in InputTransformer.shortcuts {
        let down = t.flags([.maskShift], key: code, down: true, terminal: false)
        check(down.contains([.maskCommand,.maskShift]) && !down.contains(.maskControl), "Ctrl shortcut down")
        t.controls.removeAll()
        let up = t.flags([], key: code, down: false, terminal: false)
        check(up.contains(.maskCommand), "paired shortcut release after Ctrl release")
        t.controls.insert(79)
    }
    check(t.flags([], key: 8, down: true, terminal: true).contains(.maskControl), "terminal Ctrl preserved")
    check(t.flags([], key: 18, down: true, terminal: false).contains(.maskControl), "unlisted shortcut preserved")
    check(t.flags([.maskAlternate], key: 8, down: true, terminal: false).contains(.maskControl), "Ctrl Option combination preserved")
    var plain = InputTransformer()
    check(plain.flags(.maskControl, key: 8, down: true, terminal: false) == .maskControl, "built-in Control unchanged without mapped external Control")
    let legacy = try JSONDecoder().decode(Preferences.self, from: Data("{\"externalOnly\":false}".utf8))
    check(!legacy.externalOnly && legacy.rightControlHanja && legacy.showLanguagePopup, "preference migration")
    var hanjaOnly = p; hanjaOnly.languageSwitch = false; hanjaOnly.ctrlShortcuts = false
    check(NativeMappings.desired(hanjaOnly, inputReady: true).first { $0.source == base | 0xE4 }?.destination == base | 0x6C, "Hanja works independently of language and Ctrl shortcuts")
    hanjaOnly.rightControlHanja = false
    check(!NativeMappings.desired(hanjaOnly, inputReady: true).contains { $0.source == base | 0xE4 }, "right Ctrl stays native with both options off")
    for down in [true, false] {
        let event = CGEvent(keyboardEventSource: nil, virtualKey: 64, keyDown: down)!
        event.flags = [.maskControl, .maskCommand]
        let converted = InputTransformer.hanjaEvent(event)
        check(converted?.getIntegerValueField(.keyboardEventKeycode) == 36, "Hanja down/up targets Return")
        check(converted?.flags == .maskAlternate, "Hanja down/up uses Option only")
        check(converted?.type == (down ? .keyDown : .keyUp), "Hanja retains down/up pairing")
    }
    let repeatEvent = CGEvent(keyboardEventSource: nil, virtualKey: 64, keyDown: true)!
    repeatEvent.setIntegerValueField(.keyboardEventAutorepeat, value: 1)
    check(InputTransformer.hanjaEvent(repeatEvent) == nil, "holding Hanja does not repeatedly open candidates")
    let previous = try JSONDecoder().decode(Preferences.self, from: Data("{\"rightControlLanguageSwitch\":false,\"showLanguagePopup\":false,\"externalOnly\":false}".utf8))
    check(previous.rightControlHanja && !previous.showLanguagePopup && !previous.externalOnly, "new Hanja default while preserving unrelated existing choices")
    var disabledHanja = p; disabledHanja.rightControlHanja = false
    let restored = try JSONDecoder().decode(Preferences.self, from: JSONEncoder().encode(disabledHanja))
    check(!restored.rightControlHanja, "Hanja off preference survives restart")
    check(noPermission.isEmpty, "no partial remapping before permission")
    var release = InputTransformer()
    check(release.control(79, down: true, flags: []).contains(.maskControl), "mapped Control press")
    check(!release.control(79, down: false, flags: [.maskControl]).contains(.maskControl), "release clears stale Control flag")
    _ = release.control(79, down: true, flags: [])
    _ = release.control(80, down: true, flags: [])
    check(release.control(79, down: false, flags: []).contains(.maskControl), "second Control remains held")
    check(!release.control(80, down: false, flags: []).contains(.maskControl), "both Controls released")
    release.nativeControlHeld = true
    _ = release.control(79, down: true, flags: [.maskControl])
    check(release.control(79, down: false, flags: [.maskControl]).contains(.maskControl), "native Control survives mapped Control release")
    check(LanguageSwitcher.isKorean("com.apple.inputmethod.Korean.2SetKorean"), "Korean input mode recognized")
    check(!LanguageSwitcher.isKorean("com.apple.keylayout.ABC"), "English is separate from Korean")
    check(LanguageSwitcher.englishChoice(["com.apple.keylayout.ABC", "com.apple.keylayout.US"], preferred: "com.apple.keylayout.US") == "com.apple.keylayout.US", "user English input source preserved")
    check(LanguageSwitcher.englishChoice(["com.apple.keylayout.ABC"], preferred: "missing") == "com.apple.keylayout.ABC", "ABC fallback")
    check(LanguageSwitcher.englishChoice([], preferred: "missing") == nil, "missing input source handled")
    var loginOff = p; loginOff.startAtLogin = false
    let loginDecoded = try JSONDecoder().decode(Preferences.self, from: JSONEncoder().encode(loginOff))
    check(!loginDecoded.startAtLogin, "login opt out persists")
    check(AppInstallation.isInstalled(URL(fileURLWithPath: "/Applications/WinKeys.app")), "installed system app")
    check(AppInstallation.isInstalled(URL(fileURLWithPath: NSHomeDirectory() + "/Applications/WinKeys.app")), "installed user app")
    check(!AppInstallation.isInstalled(URL(fileURLWithPath: "/Volumes/WinKeys/WinKeys.app")), "disk image cannot register login")
    check(!AppInstallation.isInstalled(URL(fileURLWithPath: NSHomeDirectory() + "/Downloads/WinKeys.app")), "downloaded app must install before registration")
    check(InputTransformer.languagePress(type: .keyDown, autorepeat: 0), "fresh language press")
    check(InputTransformer.languagePress(type: .keyDown, autorepeat: 0), "missing keyUp cannot block next language press")
    check(!InputTransformer.languagePress(type: .keyDown, autorepeat: 1), "language autorepeat ignored")
    check(!InputTransformer.languagePress(type: .keyUp, autorepeat: 0), "release does not toggle")
    try runVerifiedSwitchTests()
    print("PASS: \(count) native mapping and input transformation tests")
}

// Uses real macOS input sources and the same background-thread request as the
// event tap. It posts no keyboard events and restores the original input source.
func runLanguageIntegrationTests() throws {
    _ = NSApplication.shared
    let original = TISCopyCurrentKeyboardInputSource().takeRetainedValue()
    defer { _ = TISSelectInputSource(original) }
    let switcher = LanguageSwitcher()
    switcher.prepare(); switcher.noteSelection()
    guard switcher.ready else { throw NSError(domain: "WinKeysTests", code: 1, userInfo: [NSLocalizedDescriptionKey: "Korean and English sources unavailable"]) }
    var previous = LanguageSwitcher.string(original, kTISPropertyInputSourceID)
    var durations: [Double] = []
    for index in 0..<20 {
        var completed = false
        var passed = false
        let start = Date()
        Thread.detachNewThread {
            switcher.requestToggle { success in
                let current = LanguageSwitcher.string(TISCopyCurrentKeyboardInputSource().takeRetainedValue(), kTISPropertyInputSourceID)
                passed = Thread.isMainThread && success && LanguageSwitcher.isKorean(current) != LanguageSwitcher.isKorean(previous)
                previous = current
                durations.append(Date().timeIntervalSince(start) * 1000)
                completed = true
            }
        }
        let deadline = Date().addingTimeInterval(3)
        while !completed && Date() < deadline {
            RunLoop.current.run(until: Date().addingTimeInterval(0.005))
        }
        guard completed && passed else { throw NSError(domain: "WinKeysTests", code: 2, userInfo: [NSLocalizedDescriptionKey: "Real input-source toggle \(index + 1) failed"]) }
    }
    let median = durations.sorted()[durations.count / 2]
    print(String(format: "PASS: 20 real Korean/English switches requested from background threads; median %.1f ms, max %.1f ms; no crash", median, durations.max()!))
}

func runPopupTests() throws {
    _ = NSApplication.shared
    guard !NSWorkspace.shared.runningApplications.contains(where: {
        $0.bundleIdentifier == "local.winkeys.mac" && $0.processIdentifier != ProcessInfo.processInfo.processIdentifier
    }) else {
        throw NSError(domain: "WinKeysTests", code: 3, userInfo: [NSLocalizedDescriptionKey: "Quit WinKeys before the isolated popup test"])
    }
    let defaults = UserDefaults.standard
    let savedPreferences = defaults.data(forKey: "preferences")
    let savedSystem = PopupPreference.keys.map { CFPreferencesCopyValue($0, kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost) }
    defer {
        if let savedPreferences { defaults.set(savedPreferences, forKey: "preferences") }
        else { defaults.removeObject(forKey: "preferences") }
        defaults.synchronize()
        for (key, value) in zip(PopupPreference.keys, savedSystem) {
            CFPreferencesSetValue(key, value, kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
        }
        _ = CFPreferencesSynchronize(kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
    }
    let controller = AppDelegate()
    controller.item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    controller.makeWindow()
    controller.engine.preferences = Preferences()
    let mappings = Dictionary(uniqueKeysWithValues: NativeMappings.devices().map { ($0.id, $0.mapping) })
    let button = controller.checks[.showLanguagePopup]!
    var count = 0
    func check(_ value: Bool, _ message: String) {
        count += 1
        if !value { fatalError("FAIL: \(message)") }
    }
    func systemIndicatorsHidden() -> Bool {
        PopupPreference.keys.allSatisfy {
            guard let value = CFPreferencesCopyAppValue($0, kCFPreferencesAnyApplication) else { return false }
            return CFGetTypeID(value) == CFBooleanGetTypeID() && (value as? NSNumber)?.boolValue == false
        }
    }
    // Reproduce 2.0.3's regression, then ensure startup and ON migrate it to false.
    CFPreferencesSetValue(PopupPreference.key, NSNumber(value: 2), kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
    CFPreferencesSetValue(PopupPreference.floatingKey, kCFBooleanTrue, kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
    controller.applyPopupPreference()
    check(systemIndicatorsHidden(), "startup migrates old nonzero values to Boolean false")
    check(controller.window.title.contains(controller.appVersion), "settings title contains bundle version")
    button.state = .on; controller.toggle(button)
    controller.showPopup()
    check(controller.popup?.isVisible == true, "ON displays the actual WinKeys panel")
    check(systemIndicatorsHidden(), "ON displays only our popup without re-enabling system indicators")
    button.state = .off; controller.toggle(button)
    check(controller.popup?.isVisible == false, "OFF immediately dismisses a visible panel")
    check(systemIndicatorsHidden(), "OFF keeps inline and legacy system indicators disabled")
    controller.showPopup(); controller.inputChanged()
    RunLoop.current.run(until: Date().addingTimeInterval(0.55))
    check(controller.popup?.isVisible == false, "queued input notifications cannot redisplay after OFF")
    let persisted = try JSONDecoder().decode(Preferences.self, from: defaults.data(forKey: "preferences")!)
    check(!persisted.showLanguagePopup, "OFF persists for next launch")
    check(persisted.ctrlShortcuts && persisted.rightControlHanja && persisted.languageSwitch && persisted.startAtLogin, "other preferences preserved")
    check(mappings == Dictionary(uniqueKeysWithValues: NativeMappings.devices().map { ($0.id, $0.mapping) }), "popup toggle does not alter keyboard mappings")
    button.state = .on; controller.toggle(button); controller.showPopup()
    check(controller.popup?.isVisible == true && systemIndicatorsHidden(), "ON works again after OFF")
    button.state = .off; controller.toggle(button); controller.toggle(button)
    check(!controller.engine.preferences.showLanguagePopup && controller.popup?.isVisible == false, "checkbox state is authoritative on repeated callbacks")
    controller.dismissPopup(); controller.window.close()
    NSStatusBar.system.removeStatusItem(controller.item)
    print("PASS: \(count) popup ON/OFF integration checks; original preferences restored")
}

// Reproduces successful API return without a source change, app-switch races,
// rapid presses and secure-input interruption without posting keyboard events.
func runVerifiedSwitchTests() throws {
    var current = "en", pid: Int32 = 100, allowed = true
    var queued: [() -> Void] = [], selections: [String] = [], results: [Bool] = []
    var apply = false, count = 0
    let coordinator = VerifiedInputSwitch(current: { current }, context: { pid }, allowed: { allowed },
        select: { target in selections.append(target); if apply { current = target }; return true },
        schedule: { queued.append($0) })
    func check(_ value: Bool, _ message: String) { count += 1; precondition(value, message) }
    func drain() { while !queued.isEmpty { queued.removeFirst()() } }
    coordinator.request(target: "ko") { results.append($0) }
    check(results.isEmpty, "API success alone must not report success")
    check(selections == ["ko"], "first selection is immediate")
    apply = true; drain()
    check(selections == ["ko", "ko"] && results == [true], "retry same target, never toggle back")
    selections = []; results = []; apply = false; current = "en"
    coordinator.request(target: "ko") { results.append($0) }; drain()
    check(selections.count == 2 && results == [false], "bounded retry reports permanent failure")
    selections = []; results = []
    coordinator.request(target: "ko") { results.append($0) }; pid = 101; drain()
    check(selections.count == 1 && results == [false], "pending retry cannot change another app")
    results = []; selections = []
    coordinator.request(target: "ko") { results.append($0) }; coordinator.cancel(); drain()
    check(selections.count == 1 && results == [false], "typing or native shortcut cancels recovery")
    results = []; selections = []
    coordinator.request(target: "ko") { results.append($0) }
    check(coordinator.intendedSource == "ko", "rapid presses use pending target")
    coordinator.request(target: "en") { results.append($0) }; apply = true; drain()
    check(selections == ["ko", "en"] && results == [false, true], "old verification cannot undo newer press")
    results = []; selections = []; allowed = false
    coordinator.request(target: "ko") { results.append($0) }; drain()
    check(selections.isEmpty && results == [false], "secure input blocks requests")
    results = []; allowed = true; apply = false
    coordinator.request(target: "ko") { results.append($0) }; allowed = false; drain()
    check(selections.count == 1 && results == [false], "secure input cancels pending retries")
    allowed = true; apply = true; current = "en"; selections = []; results = []
    coordinator.request(target: "ko", reassert: true) { results.append($0) }
    coordinator.contextChanged(); drain()
    check(selections == ["ko", "ko"] && results == [true], "delayed same-app activation retains request and reasserts IME")
    selections = []; results = []; current = "en"
    coordinator.request(target: "ko", reassert: true) { results.append($0) }
    pid += 1; coordinator.contextChanged(); drain()
    check(selections == ["ko"] && results == [false], "focus recovery cannot escape to next app")
    selections = []; results = []; current = "en"
    coordinator.request(target: "ko", reassert: true) { results.append($0) }
    coordinator.cancel(); drain()
    check(selections == ["ko"] && results == [false], "typing cancels even successful-ID IME reactivation")
    selections = []; results = []; current = "en"
    coordinator.request(target: "ko", reassert: true) { results.append($0) }
    coordinator.request(target: "en") { results.append($0) }; drain()
    check(selections == ["ko", "en"] && results == [false, true], "rapid second press supersedes focus repair")
    print("PASS: \(count) verified input-source recovery tests")
}

func runLayoutTests() {
    _ = NSApplication.shared
    let controller = AppDelegate()
    controller.makeWindow()
    precondition(controller.window.styleMask.contains(.resizable), "settings window must be resizable")
    precondition(controller.details.count == 4 && controller.details.allSatisfy { !$0.isHidden }, "all settings must remain visible without disclosure")
    let sizes = [NSSize(width: 480, height: 360), NSSize(width: 600, height: 680), NSSize(width: 850, height: 720)]
    for showSetup in [false, true] {
        controller.setup.isHidden = !showSetup
        controller.setupText.stringValue = "시스템 설정에서 손쉬운 사용 권한을 허용하세요. 이미 켜져 있다면 기존 맥한영 항목을 삭제하고 새 앱을 다시 추가하세요."
        for size in sizes {
            controller.window.setContentSize(size)
            controller.layoutWindow()
            let doc = controller.scrollView.documentView!
            precondition(doc.isFlipped, "scrolling must start at the heading")
            precondition(abs(controller.window.contentView!.frame.width - size.width) < 1 && abs(controller.window.contentView!.frame.height - size.height) < 1, "layout updates must preserve user size")
            precondition(abs(doc.frame.width - controller.scrollView.contentView.bounds.width) < 1, "content must fit the viewport width")
            precondition(doc.frame.height >= controller.stack.fittingSize.height, "scroll document must contain all settings")
            for group in controller.details {
                precondition(group.frame.height > 90 && group.frame.maxX <= doc.bounds.maxX, "groups must fit without horizontal clipping")
            }
            controller.scrollView.contentView.scroll(to: NSPoint(x: 0, y: max(0, doc.frame.height - controller.scrollView.contentView.bounds.height)))
            let offset = controller.scrollView.contentView.bounds.origin.y
            controller.layoutWindow()
            precondition(abs(controller.scrollView.contentView.bounds.origin.y - offset) < 1, "updates must preserve scroll position")
        }
    }
    controller.window.close()
    print("PASS: six settings layouts; all groups visible, resizable width/height, wrapping content and retained scroll position")
}

import AppKit
import Carbon
import ServiceManagement

final class SettingsDocumentView: NSView {
    override var isFlipped: Bool { true }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    lazy var engine = KeyboardEngine()
    var engineStarted = false
    let login = LoginController()
    var item: NSStatusItem!
    var window: NSWindow!
    private let about = AboutWindowController()
    var stack: NSStackView!
    var details: [NSView] = []
    var lastPresentation = ""
    var scrollView: NSScrollView!
    var setup: NSBox!
    var setupText: NSTextField!
    var setupButton: NSButton!
    var popupNote: NSTextField?
    var functionKeysCheck: NSButton?
    var checks: [Setting: NSButton] = [:]
    var popup: NSPanel?
    var popupText: NSTextField?
    var popupHide: DispatchWorkItem?
    enum Setting: Int {
        case reverseMouseScroll, reverseTrackpadScroll, enabled, externalOnly, startAtLogin, swapModifiers, ctrlShortcuts, terminalExceptions, languageSwitch, rightControlHanja, showLanguagePopup
        var title: String {
            switch self {
            case .reverseMouseScroll: return "마우스 휠 방향 반전"
            case .reverseTrackpadScroll: return "트랙패드 · 부드러운 스크롤 방향 반전"
            case .enabled: return "키보드 · 스크롤 변환 사용"
            case .externalOnly: return "외장 키보드에만 적용"
            case .startAtLogin: return "로그인할 때 자동 실행"
            case .swapModifiers: return "Alt → Command · Windows → Option"
            case .ctrlShortcuts: return "Ctrl+C/V/X/Z 등 Windows 단축키 사용"
            case .terminalExceptions: return "터미널에서는 원래 Ctrl 단축키 사용"
            case .languageSwitch: return "한/영 키 · 오른쪽 Alt로 한영 전환"
            case .rightControlHanja: return "오른쪽 Ctrl로 한자 변환"
            case .showLanguagePopup: return "한영 전환 팝업 표시"
            }
        }
        var keyPath: WritableKeyPath<Preferences, Bool> {
            switch self {
            case .reverseMouseScroll: return \.reverseMouseScroll
            case .reverseTrackpadScroll: return \.reverseTrackpadScroll
            case .enabled: return \.enabled
            case .externalOnly: return \.externalOnly
            case .startAtLogin: return \.startAtLogin
            case .swapModifiers: return \.swapModifiers
            case .ctrlShortcuts: return \.ctrlShortcuts
            case .terminalExceptions: return \.terminalExceptions
            case .languageSwitch: return \.languageSwitch
            case .rightControlHanja: return \.rightControlHanja
            case .showLanguagePopup: return \.showLanguagePopup
            }
        }
    }
    let groups: [(String, [Setting])] = [
        ("사용", [.enabled, .externalOnly, .startAtLogin]),
        ("키 위치와 단축키", [.swapModifiers, .ctrlShortcuts, .terminalExceptions]),
        ("한영과 한자", [.languageSwitch, .rightControlHanja, .showLanguagePopup]),
        ("스크롤 방향", [.reverseMouseScroll, .reverseTrackpadScroll])
    ]
    func applicationDidFinishLaunching(_ notification: Notification) {
        guard AppInstallation.prepare() else { return }
        // Do not recover or edit HID mappings until the single-instance check is finished.
        let duplicate = NSWorkspace.shared.runningApplications.first { $0.bundleIdentifier == Bundle.main.bundleIdentifier && $0.processIdentifier != ProcessInfo.processInfo.processIdentifier && $0.bundleURL.map(AppInstallation.isInstalled) == true }
        if duplicate != nil {
            DistributedNotificationCenter.default().post(name: .init("local.winkeys.showSettings"), object: nil)
            exit(0)
        }
        NSApp.setActivationPolicy(.accessory)
        let bar = NSMenu(); let parent = NSMenuItem(); let appMenu = NSMenu()
        let settingsRow = appMenu.addItem(withTitle: "맥한영 설정…", action: #selector(showSettings), keyEquivalent: ","); settingsRow.target = self
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "맥한영 종료", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        parent.submenu = appMenu; bar.addItem(parent); NSApp.mainMenu = bar
        item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        item.button?.image = NSImage(systemSymbolName: "keyboard", accessibilityDescription: "맥한영")
        makeWindow()
        engine.changed = { [weak self] in self?.refresh() }
        login.registerOnFirstLaunch(engine.preferences.startAtLogin)
        engine.start()
        engineStarted = true
        // The checkbox controls only our panel; never re-enable a cached system HUD.
        applyPopupPreference()
        let distributed = DistributedNotificationCenter.default()
        distributed.addObserver(self, selector: #selector(inputChanged), name: .init(kTISNotifySelectedKeyboardInputSourceChanged as String), object: nil)
        distributed.addObserver(self, selector: #selector(sourcesChanged), name: .init(kTISNotifyEnabledKeyboardInputSourcesChanged as String), object: nil)
        distributed.addObserver(self, selector: #selector(showSettings), name: .init("local.winkeys.showSettings"), object: nil)
        NSWorkspace.shared.notificationCenter.addObserver(self, selector: #selector(woke), name: NSWorkspace.didWakeNotification, object: nil)
        NSWorkspace.shared.notificationCenter.addObserver(self, selector: #selector(woke), name: NSWorkspace.sessionDidBecomeActiveNotification, object: nil)
        NSWorkspace.shared.notificationCenter.addObserver(self, selector: #selector(frontChanged), name: NSWorkspace.didActivateApplicationNotification, object: nil)
        let first = !UserDefaults.standard.bool(forKey: "welcomeShown2")
        let event = NSAppleEventManager.shared().currentAppleEvent
        let atLogin = event?.paramDescriptor(forKeyword: AEKeyword(keyAELaunchedAsLogInItem))?.booleanValue == true || event?.attributeDescriptor(forKeyword: AEKeyword(keyAELaunchedAsLogInItem))?.booleanValue == true
        if first || engine.needsPermission || !atLogin { showSettings() }
        UserDefaults.standard.set(true, forKey: "welcomeShown2")
        // Ad-hoc updates have a new code identity. A permission request from an
        // older build must not suppress onboarding for the newly installed app.
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? appVersion
        if !engine.trusted && UserDefaults.standard.string(forKey: "permissionPromptedBuild") != build {
            UserDefaults.standard.set(build, forKey: "permissionPromptedBuild")
            DispatchQueue.main.async { [weak self] in self?.engine.requestPermission() }
        }
        refresh()
    }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { showSettings(); return true }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard engineStarted else { return .terminateNow }
        guard engine.stop() else {
            let alert = NSAlert()
            alert.messageText = "키보드 설정을 복원하지 못했습니다"
            alert.informativeText = "키를 모두 놓고 잠시 후 다시 종료해 주세요."
            alert.runModal(); return .terminateCancel
        }
        return .terminateNow
    }
    var appVersion: String { Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "개발 버전" }
    var keyboardPermissionName: String { ProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 27 ? "기기 제어 및 데이터 접근" : "손쉬운 사용" }
    func makeWindow() {
        let visible = NSScreen.main?.visibleFrame.size ?? NSSize(width: 1000, height: 800)
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: min(600, visible.width - 40), height: min(680, visible.height - 80)), styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "맥한영 \(appVersion)"; window.isReleasedWhenClosed = false
        window.contentMinSize = NSSize(width: 480, height: 360)
        window.tabbingMode = .disallowed
        scrollView = NSScrollView(frame: window.contentView!.bounds)
        scrollView.autoresizingMask = [.width, .height]
        scrollView.hasVerticalScroller = true; scrollView.autohidesScrollers = true
        scrollView.hasHorizontalScroller = false; scrollView.drawsBackground = false
        window.contentView!.addSubview(scrollView)
        let root = SettingsDocumentView(); root.translatesAutoresizingMaskIntoConstraints = false
        scrollView.documentView = root
        root.widthAnchor.constraint(equalTo: scrollView.contentView.widthAnchor).isActive = true
        stack = NSStackView(); stack.orientation = .vertical; stack.alignment = .leading; stack.spacing = 16
        stack.detachesHiddenViews = true; stack.translatesAutoresizingMaskIntoConstraints = false
        root.addSubview(stack)
        NSLayoutConstraint.activate([stack.leadingAnchor.constraint(equalTo: root.leadingAnchor, constant: 24), stack.trailingAnchor.constraint(equalTo: root.trailingAnchor, constant: -24), stack.topAnchor.constraint(equalTo: root.topAnchor, constant: 24), stack.bottomAnchor.constraint(equalTo: root.bottomAnchor, constant: -24)])
        func label(_ text: String, size: CGFloat = 12, secondary: Bool = true) -> NSTextField {
            let view = NSTextField(wrappingLabelWithString: text)
            view.font = .systemFont(ofSize: size)
            view.textColor = secondary ? .secondaryLabelColor : .labelColor
            view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
            return view
        }
        func addFullWidth(_ view: NSView, to column: NSStackView) {
            column.addArrangedSubview(view)
            view.widthAnchor.constraint(equalTo: column.widthAnchor).isActive = true
        }
        func box(_ title: String) -> (NSBox, NSStackView) {
            let box = NSBox(); box.title = title; box.titleFont = .systemFont(ofSize: 13, weight: .semibold)
            box.translatesAutoresizingMaskIntoConstraints = false
            addFullWidth(box, to: stack)
            let column = NSStackView(); column.orientation = .vertical; column.alignment = .leading; column.spacing = 10
            column.translatesAutoresizingMaskIntoConstraints = false
            let content = box.contentView!; content.addSubview(column)
            NSLayoutConstraint.activate([column.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 12), column.trailingAnchor.constraint(equalTo: content.trailingAnchor, constant: -12), column.topAnchor.constraint(equalTo: content.topAnchor, constant: 10), column.bottomAnchor.constraint(equalTo: content.bottomAnchor, constant: -12)])
            return (box, column)
        }
        let title = label("Windows 키보드를 Mac에서도 익숙하게", size: 21, secondary: false)
        title.font = .systemFont(ofSize: 21, weight: .semibold)
        addFullWidth(title, to: stack)
        addFullWidth(label("선택한 설정은 바로 적용되고 다음 로그인에도 유지됩니다."), to: stack)
        let (setupBox, setupColumn) = box("사용을 시작하려면")
        setup = setupBox
        setupText = label("")
        addFullWidth(setupText, to: setupColumn)
        setupButton = NSButton(title: "권한 연결", target: self, action: #selector(finishSetup))
        setupButton.bezelStyle = .rounded; setupColumn.addArrangedSubview(setupButton)
        let recommended = NSButton(title: "Windows 사용자 추천 설정 적용", target: self, action: #selector(applyRecommended))
        recommended.bezelStyle = .rounded; recommended.controlSize = .large
        stack.addArrangedSubview(recommended)
        addFullWidth(label("익숙한 Ctrl 단축키와 한영 전환, 마우스 휠 반전을 한 번에 설정합니다. 트랙패드는 현재 방향을 유지합니다."), to: stack)
        for (title, settings) in groups {
            let (group, column) = box(title)
            details.append(group)
            for setting in settings {
                let button = NSButton(checkboxWithTitle: setting.title, target: self, action: #selector(toggle(_:)))
                button.tag = setting.rawValue
                addFullWidth(button, to: column); checks[setting] = button
            }
            if settings.contains(.reverseMouseScroll) {
                addFullWidth(label("현재 macOS 방향을 기준으로 반전합니다. 연속 스크롤을 보내는 일부 마우스는 트랙패드 옵션을 따릅니다. 외장 키보드 옵션과 무관하게 적용됩니다.", size: 11), to: column)
            }
            if settings.contains(.swapModifiers) {
                let button = NSButton(checkboxWithTitle: "F1, F2 등의 키를 표준 기능 키로 사용", target: self, action: #selector(toggleFunctionKeys(_:)))
                button.toolTip = "macOS 전체 키보드 설정입니다. 키보드 자체 Fn Lock은 별도로 설정해야 할 수 있습니다."
                button.state = FunctionKeySettings.enabled ? .on : .off
                addFullWidth(button, to: column); functionKeysCheck = button
                addFullWidth(label("macOS 전체에 적용됩니다. 키보드 자체 Fn Lock은 별도입니다.", size: 11), to: column)
            }
            if settings.contains(.rightControlHanja) {
                addFullWidth(label("한자 변환은 한국어를 입력하거나 선택한 뒤 누르세요.", size: 11), to: column)
                let note = label("팝업을 즉시 켜고 끕니다. 업데이트 후 기존 앱은 한 번 다시 열어 주세요.", size: 11)
                addFullWidth(note, to: column); popupNote = note
            }
        }
        addFullWidth(label("한영 전환이 갑자기 되지 않으면 메뉴에서 ‘맥한영 다시 실행’을 선택하거나 Control + Space 키를 눌러 전환해 보세요. 권한 안내가 보이면 먼저 키보드 접근 권한을 다시 연결해 주세요."), to: stack)
        stack.addArrangedSubview(label("맥한영 버전 \(appVersion)", size: 11))
        window.center()
        if Bundle.main.object(forInfoDictionaryKey: "MacHanYoungPreview") as? Bool != true && !CommandLine.arguments.contains("--layout-test") && !CommandLine.arguments.contains("--popup-test") {
            window.setFrameAutosaveName("MacHanYoungSettingsWindow")
        }
        layoutWindow()
        scrollView.contentView.scroll(to: .zero)
    }
    @objc func applyRecommended() {
        var recommended = Preferences()
        recommended.reverseMouseScroll = true
        recommended.showLanguagePopup = engine.preferences.showLanguagePopup
        engine.preferences = recommended
        login.setEnabled(true)
        engine.save(); applyPopupPreference()
    }
    func refresh() {
        let presentation = String(describing: engine.preferences) + "\(engine.needsPermission)-\(engine.sourceReady)-\(login.needsApproval)-\(login.error ?? "")-\(engine.problem)"
        guard presentation != lastPresentation else { return }
        lastPresentation = presentation
        for (setting, check) in checks { check.state = engine.preferences[keyPath: setting.keyPath] ? .on : .off }
        if engine.needsPermission {
            setupText.stringValue = engine.trusted
                ? "키 입력 처리를 시작하지 못했습니다. 맥한영을 다시 실행해 주세요. 계속되면 \(keyboardPermissionName)에서 기존 맥한영을 삭제한 뒤 응용 프로그램의 맥한영을 다시 추가하세요."
                : "시스템 설정 → 개인정보 보호 및 보안 → \(keyboardPermissionName)에서 맥한영을 허용하세요. 이미 켜져 있어도 작동하지 않으면 기존 항목을 삭제하고 응용 프로그램의 맥한영을 다시 추가하세요. 승인 후 자동으로 시작됩니다."
            setupButton.title = "권한 다시 연결"; setup.isHidden = false
        } else if login.needsApproval || login.error != nil {
            setupText.stringValue = login.error ?? "다음 로그인에도 실행하려면 시스템 설정에서 맥한영의 자동 실행을 허용해 주세요."
            setupButton.title = "자동 실행 허용"; setup.isHidden = false
        } else if !engine.sourceReady {
            setupText.stringValue = "한국어 입력 소스를 추가하면 한영 전환을 사용할 수 있습니다."
            setupButton.title = "한국어 추가"; setup.isHidden = false
        } else if !engine.problem.isEmpty {
            setupText.stringValue = "다른 키보드 변환 앱을 종료해 주세요. 문제가 계속되면 키보드를 다시 연결해 주세요."
            setupButton.title = "다시 연결 확인"; setup.isHidden = false
        } else { setup.isHidden = true }
        item.button?.image = NSImage(systemSymbolName: engine.needsPermission ? "keyboard.badge.exclamationmark" : "keyboard", accessibilityDescription: engine.needsPermission ? "맥한영 — 권한 연결 필요" : "맥한영") ?? NSImage(systemSymbolName: "keyboard", accessibilityDescription: "맥한영")
        item.button?.toolTip = engine.needsPermission ? "맥한영: 키보드 권한을 다시 연결해 주세요" : "맥한영 \(appVersion)"
        layoutWindow()
        let menu = NSMenu()
        let settings = menu.addItem(withTitle: "맥한영 설정…", action: #selector(showSettings), keyEquivalent: ","); settings.target = self
        if engine.needsPermission {
            let permission = menu.addItem(withTitle: "키보드 권한 다시 연결…", action: #selector(finishSetup), keyEquivalent: "")
            permission.target = self
        }
        menu.addItem(.separator())
        let enabled = menu.addItem(withTitle: "키보드 변환 사용", action: #selector(toggleMenu(_:)), keyEquivalent: "")
        enabled.target = self; enabled.tag = Setting.enabled.rawValue; enabled.state = engine.preferences.enabled ? .on : .off
        let auto = menu.addItem(withTitle: "로그인할 때 자동 실행", action: #selector(toggleMenu(_:)), keyEquivalent: "")
        auto.target = self; auto.tag = Setting.startAtLogin.rawValue; auto.state = engine.preferences.startAtLogin ? .on : .off
        menu.addItem(.separator())
        let restart = menu.addItem(withTitle: "맥한영 다시 실행", action: #selector(restartApp), keyEquivalent: "")
        restart.target = self
        menu.addItem(.separator())
        let aboutItem = menu.addItem(withTitle: "맥한영에 관하여", action: #selector(showAbout), keyEquivalent: "")
        aboutItem.target = self
        let quit = menu.addItem(withTitle: "맥한영 종료", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"); quit.target = NSApp
        item.menu = menu
    }
    func layoutWindow() {
        // Keep the user's size and scroll position across input/permission updates.
        window.contentView!.layoutSubtreeIfNeeded()
        scrollView.reflectScrolledClipView(scrollView.contentView)
    }
    func change(_ tag: Int, value: Bool? = nil) {
        guard let setting = Setting(rawValue: tag) else { return }
        engine.preferences[keyPath: setting.keyPath] = value ?? !engine.preferences[keyPath: setting.keyPath]
        if setting == .startAtLogin { login.setEnabled(engine.preferences.startAtLogin) }
        if setting == .showLanguagePopup {
            applyPopupPreference()
            // A display preference must not reset held keys or reapply mappings.
            UserDefaults.standard.set(try? JSONEncoder().encode(engine.preferences), forKey: "preferences")
            refresh()
            return
        }
        if !engine.preferences.showLanguagePopup { dismissPopup() }
        engine.save()
    }
    func applyPopupPreference() {
        let visible = engine.preferences.showLanguagePopup
        if !visible { dismissPopup() }
        if PopupPreference.suppressSystemIndicators() {
            popupNote?.stringValue = "팝업을 즉시 켜고 끕니다. 업데이트 후 기존 앱은 한 번 다시 열어 주세요."
        } else {
            popupNote?.stringValue = "macOS 팝업 설정을 저장하지 못했습니다. 옵션을 다시 선택해 주세요."
        }
    }
    @objc func toggle(_ sender: NSButton) { change(sender.tag, value: sender.state == .on) }
    @objc func toggleMenu(_ sender: NSMenuItem) { change(sender.tag) }
    @objc func finishSetup() {
        if engine.needsPermission {
            engine.requestPermission()
            NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility")!)
        } else if login.needsApproval || login.error != nil {
            login.setEnabled(engine.preferences.startAtLogin); SMAppService.openSystemSettingsLoginItems()
        } else if !engine.sourceReady {
            NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.Keyboard-Settings.extension")!)
        } else { engine.wake() }
    }
    @objc func toggleFunctionKeys(_ sender: NSButton) {
        do { try FunctionKeySettings.setEnabled(sender.state == .on) }
        catch {
            let alert = NSAlert(); alert.messageText = "기능 키 설정을 변경하지 못했습니다"
            alert.informativeText = error.localizedDescription; alert.runModal()
        }
        sender.state = FunctionKeySettings.enabled ? .on : .off
    }
    @objc func restartApp() {
        guard engine.stop() else {
            let alert = NSAlert(); alert.messageText = "키보드 설정을 복원하지 못했습니다"
            alert.informativeText = "키를 모두 놓고 다시 실행을 눌러 주세요."; alert.runModal(); return
        }
        engineStarted = false
        dismissPopup()
        do { try AppRelaunch.schedule(); NSApp.terminate(nil) }
        catch {
            engine.start(); engineStarted = true
            let alert = NSAlert(); alert.messageText = "다시 실행하지 못했습니다"
            alert.informativeText = error.localizedDescription; alert.runModal()
        }
    }
    @objc func showAbout() { about.present() }
    @objc func showSettings() { functionKeysCheck?.state = FunctionKeySettings.enabled ? .on : .off; NSApp.activate(ignoringOtherApps: true); window.makeKeyAndOrderFront(nil) }
    @objc func woke() { engine.wake() }
    @objc func frontChanged() { engine.frontChanged() }
    @objc func sourcesChanged() {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.engine.preferences.languageSwitch else { return }
            self.engine.languages.prepare(); self.refresh()
        }
    }
    @objc func inputChanged() {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }; self.engine.languages.noteSelection()
            self.showPopup(); self.refresh()
        }
    }
    func showPopup() {
        guard engine.preferences.enabled, engine.preferences.languageSwitch, engine.preferences.showLanguagePopup else { dismissPopup(); return }
        if popup == nil {
            let panel = NSPanel(contentRect: NSRect(x: 0, y: 0, width: 230, height: 68), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
            panel.level = .floating; panel.isOpaque = false; panel.backgroundColor = .clear
            panel.hasShadow = true; panel.ignoresMouseEvents = true; panel.hidesOnDeactivate = false
            panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
            let background = NSVisualEffectView(frame: panel.contentView!.bounds)
            background.material = .hudWindow; background.blendingMode = .behindWindow; background.state = .active
            background.wantsLayer = true; background.layer?.cornerRadius = 16
            let text = NSTextField(labelWithString: ""); text.frame = NSRect(x: 14, y: 19, width: 202, height: 30)
            text.alignment = .center; text.font = .systemFont(ofSize: 22, weight: .semibold)
            background.addSubview(text); panel.contentView = background; popup = panel; popupText = text
        }
        popupText?.stringValue = engine.languages.name
        if let frame = NSScreen.main?.visibleFrame { popup?.setFrameOrigin(NSPoint(x: frame.midX - 115, y: frame.minY + 100)) }
        popupHide?.cancel(); popup?.orderFrontRegardless()
        let hide = DispatchWorkItem { [weak self] in self?.popup?.orderOut(nil) }; popupHide = hide
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45, execute: hide)
    }
    func dismissPopup() {
        popupHide?.cancel(); popupHide = nil
        popup?.orderOut(nil)
    }
}

if Bundle.main.object(forInfoDictionaryKey: "MacHanYoungPreview") as? Bool == true {
    let app = NSApplication.shared
    let preview = AppDelegate(); preview.makeWindow(); preview.setup.isHidden = true
    preview.layoutWindow(); preview.window.makeKeyAndOrderFront(nil)
    app.run()
} else if CommandLine.arguments.contains("--layout-test") {
    runLayoutTests()
} else if CommandLine.arguments.contains("--self-test") {
    try runTests()
} else if CommandLine.arguments.contains("--integration-test") {
    try runLanguageIntegrationTests()
} else if CommandLine.arguments.contains("--popup-test") {
    try runPopupTests()
} else if let i = CommandLine.arguments.firstIndex(of: "--relaunch-after"), CommandLine.arguments.count > i + 2, let pid = Int32(CommandLine.arguments[i + 1]) {
    AppRelaunch.runHelper(parent: pid, path: CommandLine.arguments[i + 2])
} else if let i = CommandLine.arguments.firstIndex(of: "--watch-parent"), CommandLine.arguments.count > i + 2, let pid = Int32(CommandLine.arguments[i + 1]) {
    while kill(pid, 0) == 0 { Thread.sleep(forTimeInterval: 0.5) }
    NativeMappings.recover(url: URL(fileURLWithPath: CommandLine.arguments[i + 2]))
} else {
    let application = NSApplication.shared; let delegate = AppDelegate()
    application.delegate = delegate; application.run()
}

import AppKit
import Carbon

final class KeyboardEngine {
    var preferences: Preferences
    var changed: (() -> Void)?
    let languages = LanguageSwitcher()
    let native: NativeMappings
    private let lock = NSLock()
    private var snapshot: Preferences
    private var suspended = true
    private var transform = InputTransformer()
    private var frontBundle = ""
    private var tap: CFMachPort?
    private var source: CFRunLoopSource?
    private var tapLoop: CFRunLoop?
    private var thread: Thread?
    private var watchdog: Process?
    private var timer: Timer?
    private var stopped = false
    private var secure = false
    private var error = ""
    private var controlCount = 0
    private var languageCount = 0
    private var hanjaCount = 0
    private var mappingSignature = ""
    private var resetNeeded = false
    var devices: [String] = []
    private let terminals: Set<String> = ["com.apple.Terminal", "com.googlecode.iterm2", "com.mitchellh.ghostty"]
    var trusted: Bool { AXIsProcessTrusted() }
    var filterReady: Bool { lock.lock(); defer { lock.unlock() }; return tap != nil && !suspended }
    var ready: Bool { preferences.enabled && filterReady && !devices.isEmpty }
    var needsPermission: Bool { !trusted || !filterReady && !secure }
    var sourceReady: Bool { !preferences.languageSwitch || languages.ready }
    var problem: String { error }

    init() {
        let stored = UserDefaults.standard.data(forKey: "preferences").flatMap { try? JSONDecoder().decode(Preferences.self, from: $0) }
        preferences = stored ?? Preferences(); snapshot = preferences
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("WinKeys")
        native = NativeMappings(url: dir.appendingPathComponent("native-mappings.json"))
    }
    func start() {
        timer?.invalidate()
        stopped = false
        if preferences.languageSwitch { languages.prepare(); languages.noteSelection() }
        update()
        timer = Timer.scheduledTimer(withTimeInterval: 0.75, repeats: true) { [weak self] _ in self?.update() }
    }
    func save() {
        UserDefaults.standard.set(try? JSONEncoder().encode(preferences), forKey: "preferences")
        languages.cancelPending()
        lock.lock(); snapshot = preferences; resetNeeded = true; lock.unlock()
        if preferences.languageSwitch && !languages.ready { languages.prepare() }
        update()
    }
    func requestPermission() {
        _ = AXIsProcessTrustedWithOptions([kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary)
        update()
    }
    func wake() {
        languages.resetContext()
        lock.lock(); resetNeeded = true; lock.unlock()
        update()
    }
    func frontChanged() {
        lock.lock(); frontBundle = NSWorkspace.shared.frontmostApplication?.bundleIdentifier ?? ""; lock.unlock()
        languages.refreshContext()
    }
    func update() {
        guard !stopped else { return }
        let wasSecure = secure
        secure = IsSecureEventInputEnabled()
        if secure != wasSecure { languages.resetContext() }
        let newFront = NSWorkspace.shared.frontmostApplication?.bundleIdentifier ?? ""
        lock.lock(); let frontChanged = newFront != frontBundle; frontBundle = newFront; lock.unlock()
        if frontChanged { languages.refreshContext() }
        if trusted && tap == nil { installTap() }
        if !trusted && tap != nil { removeTap() }
        let active = tap.map { CGEvent.tapIsEnabled(tap: $0) } ?? false
        if trusted && !secure, let tap, !active { CGEvent.tapEnable(tap: tap, enable: true) }
        let inputReady = trusted && !secure && (tap.map { CGEvent.tapIsEnabled(tap: $0) } ?? false)
        lock.lock()
        if suspended != !inputReady { resetNeeded = true }
        suspended = !inputReady; snapshot = preferences
        lock.unlock()
        do {
            devices = try native.apply(preferences, inputReady: inputReady)
            error = ""
            if !native.saved.isEmpty && (watchdog == nil || watchdog?.isRunning == false) {
                let child = Process(); child.executableURL = Bundle.main.executableURL
                child.arguments = ["--watch-parent", String(ProcessInfo.processInfo.processIdentifier), native.url.path]
                child.standardOutput = FileHandle.nullDevice; child.standardError = FileHandle.nullDevice
                try child.run(); watchdog = child
            }
        } catch { _ = native.restore(); self.error = error.localizedDescription }
        writeRuntime()
        changed?()
    }
    private func installTap() {
        let types: [CGEventType] = [.keyDown, .keyUp, .flagsChanged, .leftMouseDown, .leftMouseUp, .rightMouseDown, .rightMouseUp, .otherMouseDown, .otherMouseUp, .scrollWheel]
        let mask = types.reduce(CGEventMask(0)) { $0 | (1 << $1.rawValue) }
        guard let port = CGEvent.tapCreate(tap: .cgSessionEventTap, place: .headInsertEventTap, options: .defaultTap, eventsOfInterest: mask, callback: { _, type, event, context in
            guard let context else { return Unmanaged.passUnretained(event) }
            return Unmanaged<KeyboardEngine>.fromOpaque(context).takeUnretainedValue().process(type, event)
        }, userInfo: Unmanaged.passUnretained(self).toOpaque()) else { return }
        guard let runSource = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, port, 0) else { CFMachPortInvalidate(port); return }
        lock.lock(); tap = port; source = runSource; lock.unlock()
        let inputThread = Thread { [weak self] in
            guard let self else { return }
            let loop = CFRunLoopGetCurrent()!
            self.lock.lock()
            guard self.tap === port else { self.lock.unlock(); return }
            self.tapLoop = loop
            CFRunLoopAddSource(loop, runSource, .commonModes)
            CGEvent.tapEnable(tap: port, enable: true)
            self.lock.unlock()
            CFRunLoopRun()
            CFRunLoopRemoveSource(loop, runSource, .commonModes)
        }
        inputThread.name = "WinKeys Keyboard"; inputThread.qualityOfService = .userInteractive
        thread = inputThread; inputThread.start()
    }
    private func removeTap() {
        lock.lock(); let port = tap; let loop = tapLoop
        tap = nil; source = nil; tapLoop = nil; suspended = true; resetNeeded = true; lock.unlock()
        if let port { CGEvent.tapEnable(tap: port, enable: false); CFMachPortInvalidate(port) }
        if let loop { CFRunLoopStop(loop) }
        thread = nil
    }
    private func process(_ type: CGEventType, _ event: CGEvent) -> Unmanaged<CGEvent>? {
        if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
            lock.lock(); let port = tap; resetNeeded = true; lock.unlock()
            if let port { CGEvent.tapEnable(tap: port, enable: true) }
            return Unmanaged.passUnretained(event)
        }
        if event.getIntegerValueField(.eventSourceUserData) == InputTransformer.tag { return Unmanaged.passUnretained(event) }
        lock.lock(); defer { lock.unlock() }
        if resetNeeded { transform = InputTransformer(); resetNeeded = false }
        let p = snapshot
        guard p.enabled && !suspended else { return Unmanaged.passUnretained(event) }
        if type == .scrollWheel {
            ScrollTransformer.apply(event, preferences: p)
            return Unmanaged.passUnretained(event)
        }
        let key = Int(event.getIntegerValueField(.keyboardEventKeycode))
        let keyboard = type == .keyDown || type == .keyUp
        if keyboard && key == 90 && p.languageSwitch {
            if InputTransformer.languagePress(type: type, autorepeat: event.getIntegerValueField(.keyboardEventAutorepeat)) {
                languages.requestToggle(allowed: { [weak self] in
                    guard let self else { return false }
                    return !self.stopped && self.preferences.enabled && self.preferences.languageSwitch && self.filterReady
                }) { [weak self] success in
                    guard let self else { return }
                    self.lock.lock()
                    if success { self.languageCount += 1 }
                    self.lock.unlock()
                    self.writeRuntime()
                }
            }
            return nil
        }
        if type == .keyDown {
            // Do not let a delayed repair change the source after typing or a
            // native Control-Space switch has already started.
            DispatchQueue.main.async { [weak self] in self?.languages.cancelPending() }
        }
        if keyboard && key == 64 && p.rightControlHanja {
            guard let converted = InputTransformer.hanjaEvent(event) else { return nil }
            if type == .keyDown { hanjaCount += 1 }
            return Unmanaged.passUnretained(converted)
        }
        if keyboard && (key == 79 || key == 80) && p.ctrlShortcuts {
            if event.getIntegerValueField(.keyboardEventAutorepeat) != 0 { return nil }
            if type == .keyDown { controlCount += 1 }
            event.flags = transform.control(key, down: type == .keyDown, flags: event.flags)
            event.type = .flagsChanged
            event.setIntegerValueField(.keyboardEventKeycode, value: key == 79 ? 59 : 62)
            return Unmanaged.passUnretained(event)
        }
        if type == .flagsChanged && (key == 59 || key == 62) {
            transform.nativeControlHeld = event.flags.contains(.maskControl)
        }
        let terminal = p.terminalExceptions && (terminals.contains(frontBundle) || frontBundle.hasPrefix("dev.warp.Warp"))
        if keyboard { event.flags = transform.flags(event.flags, key: key, down: type == .keyDown, terminal: terminal) }
        else if !transform.controls.isEmpty { event.flags.insert(.maskControl) }
        return Unmanaged.passUnretained(event)
    }
    @discardableResult func stop() -> Bool {
        guard native.restore() else { return false }
        stopped = true; languages.cancelPending(); timer?.invalidate(); timer = nil
        removeTap(); watchdog?.terminate(); watchdog = nil
        writeRuntime()
        return true
    }
    private func writeRuntime() {
        lock.lock()
        let runtime: [String: Any] = ["version": Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "test", "pid": ProcessInfo.processInfo.processIdentifier, "appPath": Bundle.main.bundlePath, "running": !stopped, "accessibility": trusted, "filter": tap != nil && !suspended, "devices": devices, "controlPresses": controlCount, "languageSwitches": languageCount, "hanjaPresses": hanjaCount, "sourceReady": languages.ready, "secureInput": secure, "error": error]
        lock.unlock()
        // Counters contain no typed characters. Only used to verify actual hardware routing.
        guard let data = try? JSONSerialization.data(withJSONObject: runtime, options: [.sortedKeys]) else { return }
        let signature = String(data: data, encoding: .utf8) ?? ""
        guard signature != mappingSignature else { return }; mappingSignature = signature
        try? data.write(to: native.url.deletingLastPathComponent().appendingPathComponent("runtime.json"), options: .atomic)
    }
}

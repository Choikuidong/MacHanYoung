#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
./맥한영.app/Contents/MacOS/WinKeys --self-test
./맥한영.app/Contents/MacOS/WinKeys --layout-test
swiftc -parse-as-library Sources/Preferences.swift Sources/ScrollTransformer.swift Tests/Scroll/main.swift -o .build/scroll-tests
.build/scroll-tests

#!/bin/zsh
set -eu
cd "$(dirname "$0")"
mkdir -p .build/ModuleCache 맥한영.app/Contents/{MacOS,Resources}
task_cache_path="$(pwd)/.build/ModuleCache"
for task_arch in arm64 x86_64; do
  xcrun swiftc -module-cache-path "$task_cache_path" -target "$task_arch-apple-macosx13.0" -swift-version 5 -O Sources/*.swift -o ".build/WinKeys-$task_arch" -framework AppKit -framework Carbon -framework IOKit -framework ServiceManagement
done
lipo -create .build/WinKeys-arm64 .build/WinKeys-x86_64 -output 맥한영.app/Contents/MacOS/WinKeys
cat > 맥한영.app/Contents/Info.plist <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>WinKeys</string>
<key>CFBundleIdentifier</key><string>local.winkeys.mac</string>
<key>CFBundleName</key><string>맥한영</string>
<key>CFBundleDisplayName</key><string>맥한영</string>
<key>CFBundleDevelopmentRegion</key><string>ko</string>
<key>CFBundleVersion</key><string>31</string>
<key>CFBundleShortVersionString</key><string>1.01</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>LSUIElement</key><true/>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>NSHumanReadableCopyright</key><string>© 2026 Apple Craft. All rights reserved.</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
</dict></plist>
PLIST
xcrun swift -module-cache-path "$task_cache_path" Scripts/Icon.swift .build/AppIcon.iconset
iconutil -c icns .build/AppIcon.iconset -o 맥한영.app/Contents/Resources/AppIcon.icns
cp Resources/AppleCraftSymbol.png 맥한영.app/Contents/Resources/
mkdir -p 맥한영.app/Contents/Resources/ko.lproj 맥한영.app/Contents/Resources/en.lproj
printf '%s\n' '"CFBundleDisplayName" = "맥한영";' '"CFBundleName" = "맥한영";' > 맥한영.app/Contents/Resources/ko.lproj/InfoPlist.strings
printf '%s\n' '"CFBundleDisplayName" = "MacHanYoung";' '"CFBundleName" = "MacHanYoung";' > 맥한영.app/Contents/Resources/en.lproj/InfoPlist.strings
# Reuse a Developer ID identity for distribution to preserve permission identity.
# Without one, local ad-hoc builds require permission reconnection after updates.
if [[ -n "${MACHANYOUNG_SIGNING_IDENTITY:-}" ]]; then
  codesign --force --options runtime --timestamp --sign "$MACHANYOUNG_SIGNING_IDENTITY" 맥한영.app
else
  codesign --force --sign - 맥한영.app
fi
codesign --verify --deep --strict 맥한영.app
print '맥한영 1.01 앱 빌드 완료'

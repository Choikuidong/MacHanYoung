import AppKit
let directory = CommandLine.arguments[1]
try FileManager.default.createDirectory(atPath: directory, withIntermediateDirectories: true)
for (name, pixels) in [("icon_16x16",16),("icon_16x16@2x",32),("icon_32x32",32),("icon_32x32@2x",64),("icon_128x128",128),("icon_128x128@2x",256),("icon_256x256",256),("icon_256x256@2x",512),("icon_512x512",512),("icon_512x512@2x",1024)] {
    let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: pixels, pixelsHigh: pixels, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
    let context = NSGraphicsContext(bitmapImageRep: bitmap)!
    NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = context
    let scale = CGFloat(pixels) / 1024
    context.cgContext.scaleBy(x: scale, y: scale)
    let background = NSBezierPath(roundedRect: NSRect(x: 40,y: 40,width: 944,height: 944), xRadius: 205, yRadius: 205)
    NSGradient(starting: NSColor(calibratedRed: 0.1,green: 0.35,blue: 0.9,alpha: 1), ending: NSColor(calibratedRed: 0.32,green: 0.19,blue: 0.78,alpha: 1))!.draw(in: background, angle: 90)
    NSColor.white.withAlphaComponent(0.96).setFill()
    NSBezierPath(roundedRect: NSRect(x: 166,y: 247,width: 692,height: 470), xRadius: 70,yRadius: 70).fill()
    NSColor(calibratedRed: 0.12,green: 0.23,blue: 0.53,alpha: 1).setFill()
    for row in 0..<2 {
        for column in 0..<5 {
            NSBezierPath(roundedRect: NSRect(x: 222 + column*122,y: 407 + row*112,width: 94,height: 76), xRadius: 18,yRadius: 18).fill()
        }
    }
    NSBezierPath(roundedRect: NSRect(x: 311,y: 312,width: 400,height: 58), xRadius: 18,yRadius: 18).fill()
    NSGraphicsContext.restoreGraphicsState()
    try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: directory+"/"+name+".png"))
}

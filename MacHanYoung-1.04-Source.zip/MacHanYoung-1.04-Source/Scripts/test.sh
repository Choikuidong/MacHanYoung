#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
./맥한영.app/Contents/MacOS/WinKeys --self-test
./맥한영.app/Contents/MacOS/WinKeys --layout-test
swiftc -parse-as-library Sources/Preferences.swift Sources/ScrollTransformer.swift Tests/Scroll/main.swift -o .build/scroll-tests
.build/scroll-tests
swiftc -parse-as-library Sources/SettingsTheme.swift Sources/InputTransformer.swift Sources/SymbolPicker.swift Tests/Symbols/main.swift -o .build/symbol-tests -framework AppKit -framework Carbon
.build/symbol-tests

swiftc -parse-as-library Sources/Preferences.swift Sources/UpdatePolicy.swift Tests/Updates/main.swift -o .build/update-tests
.build/update-tests
swiftc -parse-as-library Sources/SettingsTheme.swift Sources/UpdatePolicy.swift Sources/UpdateWindowController.swift Tests/Updates/UI.swift -o .build/update-ui-tests -framework AppKit
.build/update-ui-tests

import Foundation
import IOKit.hidsystem
let key = FunctionKeySettings.key
let saved = CFPreferencesCopyValue(key, kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
let oldEnabled = FunctionKeySettings.enabled
let service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("IOHIDSystem"))
var connection: io_connect_t = 0
precondition(IOServiceOpen(service, mach_task_self_, UInt32(kIOHIDParamConnectType), &connection) == KERN_SUCCESS)
IOObjectRelease(service)
var originalRaw: Unmanaged<CFTypeRef>?
precondition(IOHIDCopyCFTypeParameter(connection, kIOHIDFKeyModeKey as CFString, &originalRaw) == KERN_SUCCESS)
let originalRuntime = originalRaw?.takeRetainedValue()
defer {
    try? FunctionKeySettings.setEnabled(oldEnabled)
    if let originalRuntime { _ = IOHIDSetCFTypeParameter(connection, kIOHIDFKeyModeKey as CFString, originalRuntime) }
    CFPreferencesSetValue(key, saved, kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
    CFPreferencesSynchronize(kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
    IOServiceClose(connection)
}
for enabled in [true, false, true] {
    try FunctionKeySettings.setEnabled(enabled)
    var currentRaw: Unmanaged<CFTypeRef>?
    precondition(IOHIDCopyCFTypeParameter(connection, kIOHIDFKeyModeKey as CFString, &currentRaw) == KERN_SUCCESS)
    let current = currentRaw?.takeRetainedValue()
    precondition((current as? NSNumber)?.boolValue == enabled, "Live HID mode must match")
    precondition(FunctionKeySettings.enabled == enabled, "Persistent macOS setting must match")
}
print("PASS: standard function keys ON/OFF/ON updates live HID and stored preferences; original state restored")

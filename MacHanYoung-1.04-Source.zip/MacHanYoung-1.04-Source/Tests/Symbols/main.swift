import AppKit
import Foundation

@main struct SymbolReferenceTests {
    static func main() throws {
        let reference = try JSONDecoder().decode([String: [String]].self, from: Data(contentsOf: URL(fileURLWithPath: "Tests/SymbolReference.json")))
        precondition(SymbolCatalog.groups == reference, "compiled catalog must exactly match the ordered reference")
        precondition(reference.count == 19 && reference.values.reduce(0) { $0 + $1.count } == 1038)
        precondition(reference["ㅉ"] == [], "never invent a mapping for an unassigned consonant")
        precondition(reference["ㄲ"]?.count == 53 && reference["ㄸ"]?.count == 83 && reference["ㅃ"]?.count == 86 && reference["ㅆ"]?.count == 66)
        precondition(reference["ㅆ"]?[6] == "Ё" && reference["ㅆ"]?[39] == "ё", "Cyrillic Yo remains in alphabetic order")
        precondition(reference["ㄱ"]?[20] == "\u{00AD}", "soft hyphen preserved")
        precondition(reference["ㄹ"]?[7] == "Å" && reference["ㄹ"]?[71] == "Ω", "reference compatibility characters preserved without normalization")
        precondition(InputTransformer.symbolShortcutKeys == [41,47], "both semicolon and period")
        print("PASS: all 1,038 reference entries, 19 consonant categories, four populated double-consonants, exact order/codepoints, both Windows shortcuts")
    }
}

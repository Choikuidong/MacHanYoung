import AppKit
@main struct UpdateUITests { static func main() { UpdateWindowController.runUITests() } }

import Foundation

@main struct UpdateTests {
    static func main() throws {
        var count = 0
        func check(_ ok: Bool, _ text: String) { count += 1; precondition(ok,text) }
        func release(_ version: String) -> PublishedRelease {
            PublishedRelease(tag_name: version,name: "맥한영",body: "새로운 기능",html_url: "https://github.com/Choikuidong/MacHanYoung/releases/tag/\(version)",draft:false,prerelease:false,assets:[.init(name:"MacHanYoung-\(version).dmg",state:"uploaded")])
        }
        check(AppVersion("v1.04")! > AppVersion("1.03")!,"newer version")
        check(AppVersion("1.10")! > AppVersion("1.09")!,"numeric components, never decimal floats")
        check(AppVersion("1.04") == AppVersion("1.4.0"),"leading zero and patch equivalence")
        check(AppVersion("1.04.1")! > AppVersion("1.04")!,"patch update")
        for invalid in ["1","1..04","1.04-beta","9999999.1","https://bad.test","1.2.3.4",""] { check(AppVersion(invalid)==nil,"reject malformed tags") }
        check(release("v1.05").isInstallable,"published stable DMG accepted")
        let body = try JSONSerialization.data(withJSONObject:["tag_name":"v1.05","name":"맥한영","body":"업데이트","html_url":"https://github.com/Choikuidong/MacHanYoung/releases/tag/v1.05","draft":false,"prerelease":false,"assets":[["name":"MacHanYoung-1.05.dmg","state":"uploaded"]]])
        if case .success(let parsed) = PublishedRelease.decode(body,status:200) { check(parsed.version=="1.05","decode stable API release") } else { fatalError("valid response rejected") }
        check(PublishedRelease.decode(body,status:429) == .failure(.rateLimited),"HTTP rate limit")
        check(PublishedRelease.decode(body,status:404) == .failure(.noRelease),"no release")
        check(PublishedRelease.decode(Data("bad json".utf8),status:200) == .failure(.invalidResponse),"bad response")
        for pair in [("draft",true as Any),("prerelease",true as Any),("html_url","https://evil.test/Choikuidong/MacHanYoung/releases/tag/v1.05" as Any),("assets",[] as Any)] {
            var object = try JSONSerialization.jsonObject(with:body) as! [String:Any];object[pair.0] = pair.1
            if case .failure = PublishedRelease.decode(try JSONSerialization.data(withJSONObject:object),status:200) { check(true,"reject unsafe/incomplete release") } else { fatalError("invalid release accepted") }
        }
        let suite = "MacHanYoung.UpdateTests."+UUID().uuidString
        let defaults = UserDefaults(suiteName:suite)!
        defer { defaults.removePersistentDomain(forName:suite) }
        var clock = Date(timeIntervalSince1970:1000000)
        var pending: [(Result<PublishedRelease,UpdateError>)->Void] = []
        var notices: [UpdateChecker.Notice] = []
        let checker = UpdateChecker(version:"1.04",defaults:defaults,now:{clock},fetch:{pending.append($0)})
        checker.show = {notice,_ in notices.append(notice)}
        checker.check(manual:false);checker.check(manual:false)
        check(pending.count==1 && checker.checking,"deduplicate in-flight checks")
        pending.removeFirst()(.success(release("v1.05")))
        check(checker.available?.version=="1.05" && notices.count==1,"automatic new-version notice")
        checker.check(manual:false);check(pending.isEmpty,"at most one automatic request daily")
        checker.check(manual:true);check(notices.count==2 && pending.isEmpty,"manual opens known update without redundant HTTP")
        notices=[];clock.addTimeInterval(24*3600)
        checker.check(manual:false);pending.removeFirst()(.success(release("v1.05")))
        check(notices.isEmpty,"same version not repeatedly announced")
        checker.setAutomatic(false);clock.addTimeInterval(24*3600);checker.check(manual:false)
        check(pending.isEmpty,"opt out stops automatic HTTP")
        checker.stop()
        let off = UpdateChecker(version:"1.04",defaults:defaults,now:{clock},fetch:{pending.append($0)})
        off.setAutomatic(false);off.show = {notice,_ in notices.append(notice)}
        off.check(manual:true);check(pending.count==1,"manual works with automatic off")
        pending.removeFirst()(.success(release("v1.01")))
        check(notices.last == .current(latest:"1.01") && off.available==nil,"older GitHub release never offered as downgrade")
        off.check(manual:true);check(pending.isEmpty,"manual repeated clicks throttled")
        off.stop();notices=[]
        let interrupted = UpdateChecker(version:"1.04",defaults:defaults,now:{clock},fetch:{pending.append($0)})
        clock.addTimeInterval(24*3600);interrupted.check(manual:false);interrupted.setAutomatic(false)
        pending.removeFirst()(.success(release("v1.06")))
        check(notices.isEmpty,"no automatic popup after opt out")
        interrupted.stop()
        check(UpdateChecker.homepage.absoluteString=="https://applecraft.kr/?view=programs#app-machanyoung","download always opens maker homepage")
        let prefs = try JSONDecoder().decode(Preferences.self,from:Data("{}".utf8))
        check(prefs.automaticUpdates,"existing preferences migrate to automatic ON")
        var saved = prefs;saved.automaticUpdates=false
        check(!(try JSONDecoder().decode(Preferences.self,from:JSONEncoder().encode(saved))).automaticUpdates,"opt out persists")
        print("PASS: \(count) update checks: versions, release validation, daily cadence, no duplicate notices, opt out, manual checks, downgrade prevention, maker homepage")
        if CommandLine.arguments.contains("--live") {
            var result: Result<PublishedRelease,UpdateError>?
            UpdateChecker.fetchLatest {result=$0}
            let deadline = Date().addingTimeInterval(30)
            while result==nil && Date()<deadline { RunLoop.current.run(until:Date().addingTimeInterval(0.02)) }
            guard case .success(let remote)? = result else { fatalError("Live GitHub check failed: \(String(describing:result))") }
            print("PASS: live unauthenticated GitHub latest release \(remote.version); download destination \(UpdateChecker.homepage.absoluteString)")
        }
    }
}

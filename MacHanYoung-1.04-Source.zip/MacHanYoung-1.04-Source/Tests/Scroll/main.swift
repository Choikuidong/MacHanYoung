import AppKit
@main struct Tests {
static func main() throws {
var count = 0
for continuous in [false,true] {
 for mouse in [false,true] {
  for trackpad in [false,true] {
   var p = Preferences(); p.reverseMouseScroll = mouse; p.reverseTrackpadScroll = trackpad
   let event = CGEvent(scrollWheelEvent2Source: nil, units: .pixel, wheelCount: 2, wheel1: 12, wheel2: -4, wheel3: 0)!
   event.setIntegerValueField(.scrollWheelEventIsContinuous, value: continuous ? 1 : 0)
   let before = event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1)
   ScrollTransformer.apply(event, preferences: p)
   let reverse = continuous ? trackpad : mouse
   precondition(event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1) == (reverse ? -before : before))
   ScrollTransformer.apply(event, preferences: p)
   precondition(event.getIntegerValueField(.scrollWheelEventPointDeltaAxis1) == before)
   count += 2
  }
 }
}
let old = try JSONDecoder().decode(Preferences.self, from: Data("{}".utf8))
precondition(!old.reverseMouseScroll && !old.reverseTrackpadScroll)
var paused = Preferences(); paused.enabled = false; paused.reverseMouseScroll = true
let event = CGEvent(scrollWheelEvent2Source: nil, units: .line, wheelCount: 1, wheel1: 3, wheel2: 0, wheel3: 0)!
let before = event.getIntegerValueField(.scrollWheelEventDeltaAxis1)
ScrollTransformer.apply(event, preferences: paused)
precondition(event.getIntegerValueField(.scrollWheelEventDeltaAxis1) == before)
print("PASS: \(count+2) scroll reversal and migration checks")
}}

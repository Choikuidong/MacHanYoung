import Foundation
import IOKit.hidsystem

/// The system-wide macOS preference, independent of per-device key remapping.
enum FunctionKeySettings {
    static let key = "com.apple.keyboard.fnState" as CFString
    static var enabled: Bool {
        CFPreferencesSynchronize(kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
        return (CFPreferencesCopyValue(key, kCFPreferencesAnyApplication,
                                      kCFPreferencesCurrentUser, kCFPreferencesAnyHost) as? NSNumber)?.boolValue ?? false
    }
    static func setEnabled(_ enabled: Bool) throws {
        let service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("IOHIDSystem"))
        guard service != 0 else { throw failure("키보드 시스템에 연결하지 못했습니다.") }
        defer { IOObjectRelease(service) }
        var connection: io_connect_t = 0
        guard IOServiceOpen(service, mach_task_self_, UInt32(kIOHIDParamConnectType), &connection) == KERN_SUCCESS else {
            throw failure("키보드 설정에 접근하지 못했습니다. 시스템 설정에서 기능 키를 변경해 주세요.")
        }
        defer { IOServiceClose(connection) }
        var previousRaw: Unmanaged<CFTypeRef>?
        let hadPrevious = IOHIDCopyCFTypeParameter(connection, kIOHIDFKeyModeKey as CFString, &previousRaw) == KERN_SUCCESS
        let previous = previousRaw?.takeRetainedValue()
        let oldPreference = CFPreferencesCopyValue(key, kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
        let value = NSNumber(value: enabled ? 1 : 0)
        guard IOHIDSetCFTypeParameter(connection, kIOHIDFKeyModeKey as CFString, value) == KERN_SUCCESS else {
            throw failure("기능 키 설정을 적용하지 못했습니다.")
        }
        CFPreferencesSetValue(key, enabled ? kCFBooleanTrue : kCFBooleanFalse,
                              kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
        guard CFPreferencesSynchronize(kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost) else {
            if hadPrevious, let previous { _ = IOHIDSetCFTypeParameter(connection, kIOHIDFKeyModeKey as CFString, previous) }
            CFPreferencesSetValue(key, oldPreference, kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
            _ = CFPreferencesSynchronize(kCFPreferencesAnyApplication, kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
            throw failure("기능 키 설정을 저장하지 못했습니다.")
        }
    }
    private static func failure(_ description: String) -> NSError {
        NSError(domain: "MacHanYoung.FunctionKeys", code: 1, userInfo: [NSLocalizedDescriptionKey: description])
    }
}

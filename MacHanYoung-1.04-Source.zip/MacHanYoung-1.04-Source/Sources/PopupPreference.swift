import Foundation

// HIToolbox caches indicator enablement in each client process. Re-enabling
// the system indicator whenever our checkbox changes leaves mixed cached
// states (inline/legacy HUD). Keep both system indicators disabled and let
// AppDelegate's panel be the sole owner of the user's popup ON/OFF setting.
// Apps already running when this is first applied must be reopened once.
enum PopupPreference {
    static let key = "TSMLanguageIndicatorEnabled" as CFString
    static let floatingKey = "FloatingIndicatorEnabled" as CFString
    static let keys = [key, floatingKey]

    @discardableResult static func suppressSystemIndicators() -> Bool {
        for key in keys {
            CFPreferencesSetValue(key, kCFBooleanFalse, kCFPreferencesAnyApplication,
                                  kCFPreferencesCurrentUser, kCFPreferencesAnyHost)
        }
        guard CFPreferencesSynchronize(kCFPreferencesAnyApplication,
                                       kCFPreferencesCurrentUser, kCFPreferencesAnyHost) else { return false }
        return keys.allSatisfy {
            (CFPreferencesCopyAppValue($0, kCFPreferencesAnyApplication) as? NSNumber)?.boolValue == false
        }
    }
}

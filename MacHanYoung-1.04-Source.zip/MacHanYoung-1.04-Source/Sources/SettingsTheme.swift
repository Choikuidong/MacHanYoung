import AppKit

enum SettingsTheme {
    static let green = NSColor(srgbRed: 0.24, green: 0.42, blue: 0.31, alpha: 1)
    static let background = NSColor(srgbRed: 0.97, green: 0.97, blue: 0.96, alpha: 1)
    static let card = NSColor(srgbRed: 0.94, green: 0.95, blue: 0.93, alpha: 1)
    static let highlight = NSColor(srgbRed: 0.91, green: 0.95, blue: 0.91, alpha: 1)
    static let ink = NSColor(srgbRed: 0.15, green: 0.20, blue: 0.17, alpha: 1)
    static let secondary = NSColor(srgbRed: 0.41, green: 0.46, blue: 0.43, alpha: 1)
}

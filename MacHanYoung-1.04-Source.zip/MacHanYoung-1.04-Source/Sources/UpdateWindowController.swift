import AppKit

/// Modeless notice: update checks never enter a modal run loop or stop input.
final class UpdateWindowController: NSObject {
    private var window: NSWindow?
    private var heading: NSTextField!
    private var versions: NSTextField!
    private var message: NSTextField!
    private var notes: NSTextView!
    private var notesScroll: NSScrollView!
    private var download: NSButton!
    private let current: String
    private let openURL: (URL) -> Bool
    init(version: String, openURL: @escaping (URL) -> Bool = { NSWorkspace.shared.open($0) }) { self.current = version; self.openURL = openURL }
    func present(_ notice: UpdateChecker.Notice, manual: Bool) {
        if window == nil { makeWindow() }
        notesScroll.isHidden = true
        download.isEnabled = true; download.title = "사과공방 홈페이지 열기"
        switch notice {
        case .checking:
            heading.stringValue = "업데이트를 확인하고 있습니다"
            versions.stringValue = "현재 버전 \(current)"
            message.stringValue = "GitHub의 최신 정식 릴리스를 확인합니다. 잠시만 기다려 주세요."
            download.isEnabled = false
        case .available(let release):
            heading.stringValue = "새로운 맥한영 \(release.version)이 있습니다"
            versions.stringValue = "현재 \(current)  →  새 버전 \(release.version)"
            message.stringValue = "사과공방 홈페이지에서 맥한영의 새 버전과 사용 안내를 확인하고 DMG를 다운로드하세요. 설치 전 실행 중인 맥한영을 종료해 주세요."
            notes.string = release.notes; notesScroll.isHidden = false
            download.title = "다운로드 안내 · 사과공방"
        case .current(let latest):
            heading.stringValue = "새 업데이트가 없습니다"
            versions.stringValue = "현재 버전 \(current) · GitHub 최신 공개 버전 \(latest)"
            message.stringValue = "현재 버전보다 새로운 정식 릴리스가 없습니다. 프로그램 소식과 사용 안내는 사과공방 홈페이지에서 확인할 수 있습니다."
        case .failure(let error):
            heading.stringValue = "업데이트를 확인하지 못했습니다"
            versions.stringValue = "현재 버전 \(current)"
            message.stringValue = error.localizedDescription
        }
        window?.contentView?.layoutSubtreeIfNeeded()
        if manual { NSApp.activate(ignoringOtherApps: true); window?.makeKeyAndOrderFront(nil) }
        else { window?.orderFrontRegardless() }
    }
    private func makeWindow() {
        let w = NSWindow(contentRect: NSRect(x: 0,y: 0,width: 540,height: 540), styleMask: [.titled,.closable,.resizable], backing: .buffered, defer: false)
        w.title = "맥한영 업데이트"; w.isReleasedWhenClosed = false
        w.contentMinSize = NSSize(width: 480,height: 520); w.backgroundColor = SettingsTheme.background; w.appearance = NSAppearance(named: .aqua)
        let stack = NSStackView(); stack.orientation = .vertical; stack.alignment = .leading; stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false; stack.detachesHiddenViews = true
        w.contentView!.addSubview(stack)
        NSLayoutConstraint.activate([stack.leadingAnchor.constraint(equalTo: w.contentView!.leadingAnchor,constant:24),stack.trailingAnchor.constraint(equalTo: w.contentView!.trailingAnchor,constant:-24),stack.topAnchor.constraint(equalTo:w.contentView!.topAnchor,constant:24),stack.bottomAnchor.constraint(lessThanOrEqualTo:w.contentView!.bottomAnchor,constant:-24)])
        func label(_ size: CGFloat, color: NSColor) -> NSTextField {
            let text = NSTextField(wrappingLabelWithString: "")
            text.font = .systemFont(ofSize:size); text.textColor = color
            text.setContentCompressionResistancePriority(.defaultLow,for:.horizontal)
            stack.addArrangedSubview(text);text.widthAnchor.constraint(equalTo:stack.widthAnchor).isActive = true
            return text
        }
        heading = label(20,color:SettingsTheme.ink);heading.font = .systemFont(ofSize:20,weight:.semibold)
        versions = label(12,color:SettingsTheme.green)
        message = label(13,color:SettingsTheme.secondary)
        notesScroll = NSScrollView();notesScroll.hasVerticalScroller = true;notesScroll.autohidesScrollers = true
        notesScroll.borderType = .bezelBorder;notesScroll.translatesAutoresizingMaskIntoConstraints = false
        notes = NSTextView(frame:NSRect(x:0,y:0,width:492,height:180))
        notes.isEditable = false;notes.isSelectable = true;notes.isRichText = false
        notes.font = .systemFont(ofSize:12);notes.textColor = SettingsTheme.ink;notes.backgroundColor = SettingsTheme.card
        notes.textContainerInset = NSSize(width:10,height:10);notes.isVerticallyResizable = true;notes.isHorizontallyResizable = false
        notes.autoresizingMask = [.width];notes.textContainer?.widthTracksTextView = true
        notesScroll.documentView = notes
        stack.addArrangedSubview(notesScroll)
        NSLayoutConstraint.activate([notesScroll.widthAnchor.constraint(equalTo:stack.widthAnchor),notesScroll.heightAnchor.constraint(equalToConstant:180)])
        let buttons = NSStackView();buttons.orientation = .horizontal;buttons.spacing = 12
        download = NSButton(title:"다운로드 안내 · 사과공방",target:self,action:#selector(openHomepage));download.bezelStyle = .rounded;download.bezelColor = SettingsTheme.green
        buttons.addArrangedSubview(download)
        let later = NSButton(title:"닫기",target:self,action:#selector(dismiss));later.bezelStyle = .rounded;buttons.addArrangedSubview(later)
        stack.addArrangedSubview(buttons)
        let footer = label(11,color:SettingsTheme.secondary)
        footer.stringValue = "사과공방 · applecraft.kr\n자동 설치하지 않습니다. 홈페이지에서 다운로드한 DMG로 직접 업데이트합니다."
        w.center();window = w
    }
    static func runUITests() {
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        var opened: [URL] = []
        let controller = UpdateWindowController(version: "1.04", openURL: { opened.append($0); return true })
        let release = PublishedRelease(tag_name: "v1.05", name: "맥한영", body: "변경 내용\n한영 전환 개선\nhttps://github.com/does-not-open", html_url: "https://github.com/Choikuidong/MacHanYoung/releases/tag/v1.05", draft: false, prerelease: false, assets: [.init(name: "MacHanYoung-1.05.dmg", state: "uploaded")])
        for notice in [UpdateChecker.Notice.checking, .current(latest: "1.01"), .failure(.network), .available(release)] {
            controller.present(notice, manual: false)
            for width in [CGFloat(480), CGFloat(700)] {
                controller.window!.setContentSize(NSSize(width: width, height: 540))
                controller.window!.contentView!.layoutSubtreeIfNeeded()
                let rect = controller.download.convert(controller.download.bounds, to: controller.window!.contentView!)
                precondition(rect.minX >= 0 && rect.minY >= 0 && rect.maxX <= width, "download button stays within resized notice")
            }
        }
        precondition(controller.versions.stringValue.contains("1.04") && controller.versions.stringValue.contains("1.05"))
        precondition(!controller.notesScroll.isHidden && controller.notes.string == release.notes)
        controller.openHomepage()
        precondition(opened == [UpdateChecker.homepage], "download only opens Apple Craft, not release notes or asset URL")
        controller.window?.close()
        let failed = UpdateWindowController(version: "1.04", openURL: { _ in false })
        failed.present(.failure(.network), manual: false); failed.openHomepage()
        precondition(failed.message.stringValue.contains("https://applecraft.kr/"), "browser failure gives the maker homepage")
        failed.window?.close()
        print("PASS: update notice states, resized layouts, current/new versions, notes, homepage-only action and browser failure")
    }
    @objc private func openHomepage() {
        if !openURL(UpdateChecker.homepage) { message.stringValue = "브라우저를 열지 못했습니다. https://applecraft.kr/ 에서 맥한영을 선택해 주세요." }
    }
    @objc private func dismiss() { window?.close() }
}

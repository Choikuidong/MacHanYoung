import Foundation
import ServiceManagement

final class LoginController {
    var error: String?
    var enabled: Bool { SMAppService.mainApp.status == .enabled }
    var needsApproval: Bool { SMAppService.mainApp.status == .requiresApproval }
    func setEnabled(_ value: Bool) {
        error = nil
        do {
            if value {
                if SMAppService.mainApp.status == .notRegistered || SMAppService.mainApp.status == .notFound {
                    try SMAppService.mainApp.register()
                }
            } else if SMAppService.mainApp.status != .notRegistered {
                try SMAppService.mainApp.unregister()
            }
        } catch { self.error = "로그인 자동 실행을 등록하지 못했습니다. 시스템 설정에서 맥한영을 추가해 주세요." }
    }
    func registerOnFirstLaunch(_ value: Bool) {
        guard AppInstallation.isInstalled(Bundle.main.bundleURL) else { return }
        let path = Bundle.main.bundleURL.standardizedFileURL.path
        // Older versions could register a mounted DMG. Migrate once from that
        // registration, then track the actual installed path instead of a flag.
        if value && UserDefaults.standard.string(forKey: "loginRegistrationPath") != path {
            do {
                if SMAppService.mainApp.status != .notRegistered {
                    try SMAppService.mainApp.unregister()
                }
            } catch {
                self.error = "자동 실행 경로를 갱신하지 못했습니다. 자동 실행을 껐다 켜 주세요."
                return
            }
        }
        setEnabled(value)
        if error == nil { UserDefaults.standard.set(path, forKey: "loginRegistrationPath") }
    }
}

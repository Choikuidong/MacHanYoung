import AppKit

enum ScrollTransformer {
    static func apply(_ event: CGEvent, preferences: Preferences) {
        let continuous = event.getIntegerValueField(.scrollWheelEventIsContinuous) != 0
        guard preferences.enabled,
              continuous ? preferences.reverseTrackpadScroll : preferences.reverseMouseScroll else { return }
        // Preserve momentum phases and precise pixel deltas. Do not synthesize events.
        let integerFields: [CGEventField] = [.scrollWheelEventDeltaAxis1, .scrollWheelEventDeltaAxis2,
                                    .scrollWheelEventPointDeltaAxis1, .scrollWheelEventPointDeltaAxis2]
        let doubleFields: [CGEventField] = [.scrollWheelEventFixedPtDeltaAxis1, .scrollWheelEventFixedPtDeltaAxis2]
        let integers = integerFields.map { event.getIntegerValueField($0) }
        let doubles = doubleFields.map { event.getDoubleValueField($0) }
        for (field, value) in zip(integerFields, integers) {
            event.setIntegerValueField(field, value: value == Int64.min ? Int64.max : -value)
        }
        for (field, value) in zip(doubleFields, doubles) {
            event.setDoubleValueField(field, value: -value)
        }
    }
}

import Foundation

/// Main-thread coordinator. A retry always selects the original target; it never
/// toggles again, and cannot leak into another app or override subsequent typing.
final class VerifiedInputSwitch {
    struct Pending {
        let id: UInt64
        let target: String
        let context: Int32
        let completion: (Bool) -> Void
    }
    private var serial: UInt64 = 0
    private var pending: Pending?
    let current: () -> String
    let context: () -> Int32
    let allowed: () -> Bool
    let select: (String) -> Bool
    let schedule: (@escaping () -> Void) -> Void

    init(current: @escaping () -> String, context: @escaping () -> Int32,
         allowed: @escaping () -> Bool, select: @escaping (String) -> Bool,
         schedule: @escaping (@escaping () -> Void) -> Void) {
        self.current = current; self.context = context; self.allowed = allowed
        self.select = select; self.schedule = schedule
    }
    var intendedSource: String? { pending?.context == context() ? pending?.target : nil }
    func cancel() {
        let old = pending; pending = nil
        old?.completion(false)
    }
    func contextChanged() {
        // Delayed/duplicate activation notifications for the same app must not
        // cancel a key press already being handled for that app.
        if let request = pending, request.context != context() { cancel() }
    }
    func request(target: String, reassert: Bool = false, completion: @escaping (Bool) -> Void) {
        cancel()
        guard allowed(), !target.isEmpty else { completion(false); return }
        serial &+= 1
        let request = Pending(id: serial, target: target, context: context(), completion: completion)
        pending = request
        _ = select(target)
        schedule { [weak self] in self?.verify(request.id, canRetry: true, reassert: reassert) }
    }
    private func verify(_ id: UInt64, canRetry: Bool, reassert: Bool = false) {
        guard let request = pending, request.id == id else { return }
        guard allowed(), context() == request.context else { cancel(); return }
        if current() == request.target && !reassert {
            pending = nil; request.completion(true)
        } else if canRetry {
            _ = select(request.target)
            schedule { [weak self] in self?.verify(id, canRetry: false) }
        } else {
            pending = nil; request.completion(false)
        }
    }
}

import AppKit
import Carbon

struct SymbolCatalog {
    // Ordered exactly as the user-supplied Windows reference; no normalization.
    static let consonants = Array("ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅋㅌㅍㅎㄲㄸㅃㅆㅉ").map(String.init)
    static let groups: [String: [String]] = [
        "ㄱ": Array("！＇，．／：；？＾＿｀｜￣、。·‥…¨〃­―∥＼∼～ˇ˘˝˚˙¸˛¡¿").map(String.init),
        "ㄴ": Array("＂（）［］｛｝‘’“”〔〕〈〉《》「」『』【】").map(String.init),
        "ㄷ": Array("＋－＜＝＞±×÷≠≤≥∞∴∵♂♀∠⊥⌒∂∇≡≒≪≫√∽∝∫∬∈∋⊆⊇⊂⊃∪∩∧∨￢⇒⇔∀∃∮∑∏").map(String.init),
        "ㄹ": Array("＄％￦Ｆ′″℃Å￠￡￥¤℉‰€㎕㎖㎗ℓ㎘㏄㎣㎤㎥㎦㎙㎚㎛㎜㎝㎞㎟㎠㎡㎢㏊㎍㎎㎏㏏㎈㎉㏈㎧㎨㎰㎱㎲㎳㎴㎵㎶㎷㎸㎹㎀㎁㎂㎃㎄㎺㎻㎼㎽㎾㎿㎐㎑㎒㎓㎔Ω㏀㏁㎊㎋㎌㏖㏅㎭㎮㎯㏛㎩㎪㎫㎬㏝㏐㏓㏃㏉㏜㏆").map(String.init),
        "ㅁ": Array("＃＆＊＠§※☆★○●◎◇◆□■△▲▽▼→←↑↓↔〓◁◀▷▶♤♠♡♥♧♣⊙◈▣◐◑▒▤▥▨▧▦▩♨☏☎☜☞¶†‡↕↗↙↖↘♭♩♪♬㉿㈜№㏇™㏂㏘℡®ªº").map(String.init),
        "ㅂ": Array("─│┌┐┘└├┬┤┴┼━┃┏┓┛┗┣┳┫┻╋┠┯┨┷┿┝┰┥┸╂┒┑┚┙┖┕┎┍┞┟┡┢┦┧┩┪┭┮┱┲┵┶┹┺┽┾╀╁╃╄╅╆╇╈╉╊").map(String.init),
        "ㅅ": Array("㉠㉡㉢㉣㉤㉥㉦㉧㉨㉩㉪㉫㉬㉭㉮㉯㉰㉱㉲㉳㉴㉵㉶㉷㉸㉹㉺㉻㈀㈁㈂㈃㈄㈅㈆㈇㈈㈉㈊㈋㈌㈍㈎㈏㈐㈑㈒㈓㈔㈕㈖㈗㈘㈙㈚㈛").map(String.init),
        "ㅇ": Array("ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑴⑵⑶⑷⑸⑹⑺⑻⑼⑽⑾⑿⒀⒁⒂").map(String.init),
        "ㅈ": Array("０１２３４５６７８９ⅰⅱⅲⅳⅴⅵⅶⅷⅸⅹⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ").map(String.init),
        "ㅊ": Array("½⅓⅔¼¾⅛⅜⅝⅞¹²³⁴ⁿ₁₂₃₄").map(String.init),
        "ㅋ": Array("ㄱㄲㄳㄴㄵㄶㄷㄸㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅃㅄㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ").map(String.init),
        "ㅌ": Array("ㅤㅥㅦㅧㅨㅩㅪㅫㅬㅭㅮㅯㅰㅱㅲㅳㅴㅵㅶㅷㅸㅹㅺㅻㅼㅽㅾㅿㆀㆁㆂㆃㆄㆅㆆㆇㆈㆉㆊㆋㆌㆍㆎ").map(String.init),
        "ㅍ": Array("ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ").map(String.init),
        "ㅎ": Array("ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωÆÐĦĲĿŁØŒÞŦŊæđðħıĳĸŀłøœßþŧŋŉ").map(String.init),
        "ㄲ": Array("ÁÀÂÄÃÅÇÉÈÊËÍÌÎÏÑÓÒÔÖÕÚÙÛÜÝáàâäãåçéèêëíìîïñóòôöõúùûüýÿ").map(String.init),
        "ㄸ": Array("ぁあぃいぅうぇえぉおかがきぎくぐけげこごさざしじすずせぜそぞただちぢっつづてでとどなにぬねのはばぱひびぴふぶぷへべぺほぼぽまみむめもゃやゅゆょよらりるれろゎわゐゑをん").map(String.init),
        "ㅃ": Array("ァアィイゥウェエォオカガキギクグケゲコゴサザシジスズセゼソゾタダチヂッツヅテデトドナニヌネノハバパヒビピフブプヘベペホボポマミムメモャヤュユョヨラリルレロヮワヰヱヲンヴヵヶ").map(String.init),
        "ㅆ": Array("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя").map(String.init),
        "ㅉ": Array("").map(String.init),
    ]
    static let emoji = ["😀","😃","😄","😁","😆","😅","😂","🙂","😊","😍","🥰","😎","🤔","😭","🙏","👍","👎","👏","🎉","✨","🔥","💡","✅","❌","❤️","💚","💙","⭐","🌟","🌸","🍎","☕","🎵","💻","📌","📎"]
    static let faces = ["(^_^)","(￣▽￣)","( •̀ ω •́ )✧","(╥﹏╥)","¯\\_(ツ)_/¯","(≧▽≦)","(づ｡◕‿‿◕｡)づ","(ง •̀_•́)ง","♡(˃͈ દ ˂͈ ༶ )"]
}

/// Reads only the selected character or one character next to the caret on demand.
/// Never stores a typed-text history or uses the clipboard.
struct SymbolTextTarget {
    let element: AXUIElement
    let range: CFRange
    let original: String
    let pid: pid_t
    static func focused() -> AXUIElement? {
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(AXUIElementCreateSystemWide(), kAXFocusedUIElementAttribute as CFString, &value) == .success,
              let value, CFGetTypeID(value) == AXUIElementGetTypeID() else { return nil }
        return (value as! AXUIElement)
    }
    static func selection(_ element: AXUIElement) -> CFRange? {
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, &value) == .success,
              let value, CFGetTypeID(value) == AXValueGetTypeID() else { return nil }
        var range = CFRange()
        guard AXValueGetValue(value as! AXValue, .cfRange, &range) else { return nil }
        return range
    }
    static func text(_ element: AXUIElement, range: CFRange) -> String? {
        var r = range; guard let value = AXValueCreate(.cfRange, &r) else { return nil }
        var result: CFTypeRef?
        guard AXUIElementCopyParameterizedAttributeValue(element, kAXStringForRangeParameterizedAttribute as CFString, value, &result) == .success else { return nil }
        return result as? String
    }
    static func capture() -> SymbolTextTarget? {
        guard !IsSecureEventInputEnabled(), let e = focused(), let selection = selection(e), selection.length <= 1 else { return nil }
        var role: CFTypeRef?
        _ = AXUIElementCopyAttributeValue(e, kAXSubroleAttribute as CFString, &role)
        guard role as? String != kAXSecureTextFieldSubrole else { return nil }
        let r = selection.length == 1 ? selection : CFRange(location: selection.location - 1, length: 1)
        guard r.location >= 0, let s = text(e, range: r), SymbolCatalog.groups[s] != nil else { return nil }
        var pid: pid_t = 0; AXUIElementGetPid(e, &pid)
        return SymbolTextTarget(element: e, range: r, original: s, pid: pid)
    }
    func valid() -> Bool {
        guard !IsSecureEventInputEnabled(), NSWorkspace.shared.frontmostApplication?.processIdentifier == pid,
              let e = Self.focused(), CFEqual(e, element), Self.text(e, range: range) == original,
              let caret = Self.selection(e) else { return false }
        return (caret.location == range.location && caret.length == 1) || (caret.location == range.location + 1 && caret.length == 0)
    }
    func replace(with symbol: String) -> Bool {
        guard valid() else { return false }
        var r = range
        guard let value = AXValueCreate(.cfRange, &r),
              AXUIElementSetAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, value) == .success else { return false }
        if AXUIElementSetAttributeValue(element, kAXSelectedTextAttribute as CFString, symbol as CFString) == .success { return true }
        // The app supports range selection but not AX replacement. Unicode key
        // events replace the selected consonant through the app's normal editor.
        SymbolPicker.post(symbol)
        return true
    }
}

final class SymbolPicker: NSObject {
    private var panel: NSPanel?
    private var grid: NSStackView!
    private var caption: NSTextField!
    private var symbolScroll: NSScrollView!
    private var expandButton: NSButton!
    private var previousButton: NSButton!
    private var nextButton: NSButton!
    private var closeButton: NSButton!
    private var expanded = false
    private var columns: Int { expanded ? 9 : 3 }
    private var pageSize: Int { expanded ? max(1, items.count) : 9 }
    private var category: NSPopUpButton!
    private var cells: [NSButton] = []
    private var items: [String] = []
    private var index = 0
    private var page = 0
    private var pid: pid_t = 0
    private var focusedElement: AXUIElement?
    private var target: SymbolTextTarget?
    private let lock = NSLock()
    private var showing = false
    private var focusTimer: Timer?
    var visible: Bool { lock.lock(); defer { lock.unlock() }; return showing }
    func close() {
        lock.lock(); showing = false; lock.unlock()
        panel?.orderOut(nil); focusTimer?.invalidate(); focusTimer = nil
        target = nil; focusedElement = nil
    }
    func open(consonant: SymbolTextTarget? = nil) {
        guard !IsSecureEventInputEnabled() else { return }
        close()
        pid = NSWorkspace.shared.frontmostApplication?.processIdentifier ?? 0
        focusedElement = SymbolTextTarget.focused(); target = consonant
        if panel == nil { makePanel() }
        if let consonant { category.selectItem(withTitle: consonant.original) }
        else { category.selectItem(withTitle: "기호") }
        expanded = false
        loadCategory()
        let mouse = NSEvent.mouseLocation
        let screen = NSScreen.screens.first { $0.frame.contains(mouse) } ?? NSScreen.main
        if let f = screen?.visibleFrame {
            panel?.setFrameOrigin(NSPoint(x: min(max(mouse.x - 200, f.minX + 8), f.maxX - (panel?.frame.width ?? 430) - 8), y: min(max(mouse.y - 330, f.minY + 8), f.maxY - (panel?.frame.height ?? 348) - 8)))
        }
        lock.lock(); showing = true; lock.unlock()
        panel?.orderFrontRegardless()
        focusTimer = Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { [weak self] _ in
            guard let self else { return }
            if IsSecureEventInputEnabled() || NSWorkspace.shared.frontmostApplication?.processIdentifier != self.pid { self.close() }
        }
    }
    /// Called on the event-tap thread; all Cocoa work is queued to main.
    func handle(key: Int, down: Bool, flags: CGEventFlags) -> Bool {
        guard visible else { return false }
        let keys: Set<Int> = [53,36,76,123,124,125,126,116,121,48,18,19,20,21,23,22,26,28,25]
        guard keys.contains(key) && !flags.contains(.maskCommand) && !flags.contains(.maskControl) else {
            if down { DispatchQueue.main.async { [weak self] in self?.close() } }
            return false
        }
        if down { DispatchQueue.main.async { [weak self] in self?.navigate(key, shift: flags.contains(.maskShift)) } }
        return true
    }
    private func makePanel() {
        let p = NSPanel(contentRect: NSRect(x: 0,y: 0,width: 430,height: 330), styleMask: [.titled,.nonactivatingPanel], backing: .buffered, defer: false)
        p.title = "특수문자 · 맥한영"; p.isReleasedWhenClosed = false; p.hidesOnDeactivate = false
        p.level = .floating; p.backgroundColor = SettingsTheme.background; p.appearance = NSAppearance(named: .aqua)
        p.collectionBehavior = [.canJoinAllSpaces,.fullScreenAuxiliary]
        let root = p.contentView!
        category = NSPopUpButton(frame: NSRect(x: 18,y: 282,width: 270,height: 28))
        category.addItems(withTitles: ["기호","이모지","이모티콘"] + SymbolCatalog.consonants)
        category.target = self; category.action = #selector(categoryChanged)
        root.addSubview(category)
        let close = NSButton(title: "닫기 Esc",target: self,action: #selector(dismiss))
        closeButton = close
        close.frame = NSRect(x: 310,y: 282,width: 102,height: 28); close.bezelStyle = .rounded; root.addSubview(close)
        symbolScroll = NSScrollView(frame: NSRect(x: 18,y: 60,width: 394,height: 208))
        symbolScroll.hasVerticalScroller = true; symbolScroll.autohidesScrollers = true; symbolScroll.drawsBackground = false
        grid = NSStackView(); grid.orientation = .vertical; grid.distribution = .fillEqually; grid.spacing = 6
        symbolScroll.documentView = grid
        root.addSubview(symbolScroll)
        caption = NSTextField(labelWithString: ""); caption.font = .systemFont(ofSize: 11); caption.textColor = SettingsTheme.secondary
        caption.frame = NSRect(x: 18,y: 9,width: 394,height: 20); root.addSubview(caption)
        let previous = NSButton(title: "이전 ◀",target: self,action: #selector(previousPage)); previousButton = previous; previous.frame = NSRect(x:18,y:32,width:90,height:24); previous.bezelStyle = .rounded; root.addSubview(previous)
        let next = NSButton(title: "다음 ▶",target:self,action:#selector(nextPage)); nextButton = next; next.frame = NSRect(x:310,y:32,width:102,height:24);next.bezelStyle = .rounded;root.addSubview(next)
        expandButton = NSButton(title: "전체 펼치기 Tab", target: self, action: #selector(toggleExpanded))
        expandButton.frame = NSRect(x: 120,y: 32,width: 185,height: 24); expandButton.bezelStyle = .rounded; root.addSubview(expandButton)
        panel = p
    }
    @objc private func dismiss() { close() }
    @objc private func categoryChanged() { loadCategory() }
    @objc private func previousPage() { turnPage(-1) }
    @objc private func nextPage() { turnPage(1) }
    private func loadCategory() {
        let title = category.titleOfSelectedItem ?? "기호"
        items = title == "이모지" ? SymbolCatalog.emoji : title == "이모티콘" ? SymbolCatalog.faces : SymbolCatalog.groups[title == "기호" ? "ㅁ" : title] ?? []
        index = 0; page = 0; render()
    }
    private func render() {
        let visibleCount = expanded ? items.count : 9
        let rows = max(1,(visibleCount+columns-1)/columns)
        let cellCount = rows*columns
        if cells.count != cellCount || grid.arrangedSubviews.count != rows {
            for row in grid.arrangedSubviews { grid.removeArrangedSubview(row); row.removeFromSuperview() }
            cells.removeAll()
            for row in 0..<rows {
                let line = NSStackView(); line.distribution = .fillEqually; line.spacing = 6
                for col in 0..<columns {
                    let b = NSButton(title: "",target: self,action: #selector(pick(_:)))
                    b.tag = row*columns+col; b.bezelStyle = .regularSquare; b.font = .systemFont(ofSize: expanded ? 21 : 23)
                    line.addArrangedSubview(b); cells.append(b)
                }
                grid.addArrangedSubview(line)
                line.widthAnchor.constraint(equalTo: grid.widthAnchor).isActive = true
            }
        }
        let width: CGFloat = expanded ? 650 : 430
        let maxHeight = max(250,(NSScreen.main?.visibleFrame.height ?? 800)-70)
        let height: CGFloat = expanded ? min(CGFloat(rows)*46+122,maxHeight) : min(330,maxHeight)
        if let panel {
            let old = panel.frame
            panel.setContentSize(NSSize(width: width,height: height))
            if visible, let screen = NSScreen.screens.first(where: { $0.frame.intersects(old) }) ?? NSScreen.main {
                let frame = screen.visibleFrame
                panel.setFrameOrigin(NSPoint(x: min(max(old.minX,frame.minX),frame.maxX-panel.frame.width), y: min(max(old.maxY-panel.frame.height,frame.minY),frame.maxY-panel.frame.height)))
            }
        }
        category.frame = NSRect(x:18,y:height-48,width:width-160,height:28)
        closeButton.frame = NSRect(x:width-120,y:height-48,width:102,height:28)
        symbolScroll.frame = NSRect(x:18,y:60,width:width-36,height:max(44,height-122))
        // A taller document provides scrolling on small displays without losing symbols.
        grid.frame = NSRect(x:0,y:0,width:symbolScroll.contentSize.width,height:expanded ? CGFloat(rows)*46 : symbolScroll.contentSize.height)
        caption.frame = NSRect(x:18,y:9,width:width-36,height:20)
        nextButton.frame = NSRect(x:width-120,y:32,width:102,height:24)
        expandButton.frame = NSRect(x:width/2-95,y:32,width:190,height:24)
        expandButton.title = expanded ? "접기 Tab" : "전체 펼치기 Tab"
        previousButton.isHidden = expanded; nextButton.isHidden = expanded
        for (i,b) in cells.enumerated() {
            let n = page*pageSize+i; b.isEnabled = n < items.count
            let symbol = n < items.count ? items[n] : ""
            let display = symbol == "\u{00AD}" ? "SHY" : symbol == "ㅤ" ? "ㅤ ␣" : symbol
            b.title = n < items.count ? (expanded ? display : "\(i+1)  \(display)") : ""
            b.toolTip = symbol.unicodeScalars.map { String(format:"U+%04X",$0.value) }.joined(separator:" ")
            b.contentTintColor = i == index ? SettingsTheme.green : SettingsTheme.ink
            b.wantsLayer = true; b.layer?.backgroundColor = (i == index ? SettingsTheme.highlight : SettingsTheme.card).cgColor
            b.setAccessibilityLabel(n < items.count ? "\(n+1)번 \(display)" : "빈 항목")
        }
        if items.isEmpty { caption.stringValue = "ㅉ에 배정된 특수문자가 없습니다. 다른 자음을 선택하세요." }
        else if expanded { caption.stringValue = "전체 \(items.count)자 · 방향키 + Enter · 마우스 선택 · Tab 접기 · Esc" }
        else { caption.stringValue = "\(page+1)/\(max(1,(items.count+8)/9)) · 숫자 1–9 · Tab 전체 · PgUp/PgDn · Esc" }
        grid.layoutSubtreeIfNeeded()
        if expanded && !cells.isEmpty {
            grid.scrollToVisible(cells[min(index,cells.count-1)].convert(cells[min(index,cells.count-1)].bounds,to:grid))
        }
    }
    @objc private func toggleExpanded() {
        let absolute = page*pageSize+index
        expanded.toggle()
        page = expanded ? 0 : absolute/9
        index = expanded ? absolute : absolute%9
        render()
    }
    private func turnPage(_ delta: Int) {
        guard !items.isEmpty else { return }
        if expanded {
            index = min(max(0,index+delta*columns*3),items.count-1); render()
        } else {
            let pages = max(1,(items.count+8)/9); page = (page+delta+pages)%pages; index = 0; render()
        }
    }
    private func navigate(_ key: Int, shift: Bool) {
        guard visible else { return }
        let numbers = [18,19,20,21,23,22,26,28,25]
        if let n = numbers.firstIndex(of:key) { commit(n); return }
        switch key {
        case 53: close()
        case 36,76: commit(index)
        case 116: turnPage(-1)
        case 121: turnPage(1)
        case 48: toggleExpanded()
        default:
            let delta = key == 123 ? -1 : key == 124 ? 1 : key == 126 ? -columns : columns
            let count = min(pageSize,items.count-page*pageSize)
            if count > 0 { index = (index+delta+count*columns)%count; render() }
        }
    }
    @objc private func pick(_ sender: NSButton) { commit(sender.tag) }
    private func commit(_ offset: Int) {
        let n = page*9+offset
        guard visible, n < items.count, !IsSecureEventInputEnabled(), NSWorkspace.shared.frontmostApplication?.processIdentifier == pid else { close(); return }
        if let target {
            guard target.replace(with: items[n]) else { NSSound.beep(); close(); return }
        } else {
            if let focusedElement {
                guard let current = SymbolTextTarget.focused(), CFEqual(focusedElement,current) else { close();return }
            }
            Self.post(items[n])
        }
        close()
    }
    static func runNavigationTests() {
        let picker = SymbolPicker(); picker.makePanel()
        picker.category.selectItem(withTitle: "ㅁ"); picker.loadCategory()
        precondition(picker.items.first == "＃" && picker.page == 0 && picker.index == 0)
        picker.lock.lock(); picker.showing = true; picker.lock.unlock()
        picker.navigate(124, shift: false)
        precondition(picker.index == 1, "Right arrow advances")
        picker.navigate(125, shift: false)
        precondition(picker.index == 4, "Down arrow advances a row")
        picker.navigate(48, shift: false)
        precondition(picker.expanded && picker.page == 0 && picker.index == 4, "Tab expands all while preserving selection")
        precondition(picker.cells.filter(\.isEnabled).count == picker.items.count, "all items have a cell")
        picker.navigate(125, shift: false)
        precondition(picker.index == 13, "expanded Down advances nine columns")
        picker.navigate(48, shift: true)
        precondition(!picker.expanded && picker.page == 1 && picker.index == 4, "Tab collapses while preserving selection")
        picker.page = 0; picker.index = 0
        picker.navigate(116, shift: false)
        precondition(picker.page == (picker.items.count-1)/9, "Previous wraps to last page")
        precondition(picker.cells.filter(\.isEnabled).count == picker.items.count-picker.page*9, "last page disables empty cells")
        picker.category.selectItem(withTitle: "이모지"); picker.loadCategory()
        precondition(picker.items == SymbolCatalog.emoji && picker.page == 0)
        picker.category.selectItem(withTitle: "이모티콘"); picker.loadCategory()
        precondition(picker.items == SymbolCatalog.faces)
        precondition(!picker.handle(key: 0, down: false, flags: []), "ordinary typing is not swallowed")
        picker.navigate(53, shift: false)
        precondition(!picker.visible, "Escape dismisses")
        precondition(!picker.handle(key: 18, down: true, flags: []), "closed picker passes numbers")
        picker.category.selectItem(withTitle: "ㄹ"); picker.loadCategory()
        picker.expanded = true; picker.render()
        precondition(picker.cells.filter(\.isEnabled).count == 94, "largest reference group has 94 selectable cells")
        picker.category.selectItem(withTitle: "ㅉ"); picker.loadCategory()
        precondition(picker.items.isEmpty && picker.caption.stringValue.contains("배정된"), "unassigned consonant is explicit, never fabricated")
        picker.panel?.close()
        print("PASS: symbol selection navigation, pages, categories, empty cells, Escape and key passthrough")
    }
    static func post(_ text: String) {
        let chars = Array(text.utf16)
        for down in [true,false] {
            guard let e = CGEvent(keyboardEventSource:nil,virtualKey:0,keyDown:down) else { continue }
            e.flags = []; e.setIntegerValueField(.eventSourceUserData,value:InputTransformer.tag)
            chars.withUnsafeBufferPointer { e.keyboardSetUnicodeString(stringLength:chars.count,unicodeString:$0.baseAddress!) }
            e.post(tap:.cgSessionEventTap)
        }
    }
}

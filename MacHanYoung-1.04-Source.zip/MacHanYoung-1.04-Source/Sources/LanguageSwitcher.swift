import AppKit
import Carbon
import Foundation

final class LanguageSwitcher {
    private var korean: TISInputSource?
    private var english: TISInputSource?
    private let lock = NSLock()
    private var observedPID: Int32?
    private var focusNeedsActivation = true
    private var lastEnglishID = UserDefaults.standard.string(forKey: "lastEnglishInputSource") ?? "com.apple.keylayout.ABC"
    private var lastKoreanID = UserDefaults.standard.string(forKey: "lastKoreanInputSource") ?? "com.apple.inputmethod.Korean.2SetKorean"

    static func string(_ source: TISInputSource, _ key: CFString) -> String {
        guard let p = TISGetInputSourceProperty(source, key) else { return "" }
        return Unmanaged<CFString>.fromOpaque(p).takeUnretainedValue() as String
    }
    static func bool(_ source: TISInputSource, _ key: CFString) -> Bool {
        guard let p = TISGetInputSourceProperty(source, key) else { return false }
        return CFBooleanGetValue(Unmanaged<CFBoolean>.fromOpaque(p).takeUnretainedValue())
    }
    static func isKorean(_ id: String) -> Bool { id.hasPrefix("com.apple.inputmethod.Korean.") }
    static func englishChoice(_ ids: [String], preferred: String) -> String? {
        [preferred, "com.apple.keylayout.ABC", "com.apple.keylayout.US"].first { ids.contains($0) }
    }
    var ready: Bool { lock.lock(); defer { lock.unlock() }; return korean != nil && english != nil }
    func prepare() {
        dispatchPrecondition(condition: .onQueue(.main))
        let all = TISCreateInputSourceList(nil, true).takeRetainedValue() as! [TISInputSource]
        // Enable the built-in parent before its Korean input mode, when not configured yet.
        if let parent = all.first(where: { Self.string($0, kTISPropertyInputSourceID) == "com.apple.inputmethod.Korean" }) {
            if !Self.bool(parent, kTISPropertyInputSourceIsEnabled) { _ = TISEnableInputSource(parent) }
        }
        let candidates = all.filter { Self.bool($0, kTISPropertyInputSourceIsSelectCapable) }
        lock.lock(); defer { lock.unlock() }
        let ko = candidates.first { Self.string($0, kTISPropertyInputSourceID) == lastKoreanID }
            ?? candidates.first { Self.string($0, kTISPropertyInputSourceID) == "com.apple.inputmethod.Korean.2SetKorean" }
        let id = Self.englishChoice(candidates.map { Self.string($0, kTISPropertyInputSourceID) }, preferred: lastEnglishID)
        let en = candidates.first { Self.string($0, kTISPropertyInputSourceID) == id }
        for source in [ko, en].compactMap({ $0 }) where !Self.bool(source, kTISPropertyInputSourceIsEnabled) { _ = TISEnableInputSource(source) }
        korean = ko.flatMap { Self.bool($0, kTISPropertyInputSourceIsEnabled) ? $0 : nil }
        english = en.flatMap { Self.bool($0, kTISPropertyInputSourceIsEnabled) ? $0 : nil }
    }
    func noteSelection() {
        dispatchPrecondition(condition: .onQueue(.main))
        let source = TISCopyCurrentKeyboardInputSource().takeRetainedValue()
        let id = Self.string(source, kTISPropertyInputSourceID)
        let languages: [String]
        if let p = TISGetInputSourceProperty(source, kTISPropertyInputSourceLanguages) {
            languages = Unmanaged<CFArray>.fromOpaque(p).takeUnretainedValue() as? [String] ?? []
        } else { languages = [] }
        lock.lock(); defer { lock.unlock() }
        if Self.isKorean(id) {
            korean = source
            if lastKoreanID != id { lastKoreanID = id; UserDefaults.standard.set(id, forKey: "lastKoreanInputSource") }
        } else if languages.contains("en") {
            english = source
            if lastEnglishID != id { lastEnglishID = id; UserDefaults.standard.set(id, forKey: "lastEnglishInputSource") }
        }
    }
    private lazy var verified = VerifiedInputSwitch(
        current: { Self.currentID },
        context: { NSWorkspace.shared.frontmostApplication?.processIdentifier ?? 0 },
        allowed: { !IsSecureEventInputEnabled() },
        select: { [weak self] id in self?.selectFresh(id) ?? false },
        schedule: { action in DispatchQueue.main.asyncAfter(deadline: .now() + 0.03, execute: action) }
    )
    static var currentID: String {
        string(TISCopyCurrentKeyboardInputSource().takeRetainedValue(), kTISPropertyInputSourceID)
    }
    func cancelPending() {
        dispatchPrecondition(condition: .onQueue(.main))
        verified.cancel()
    }
    func refreshContext() {
        dispatchPrecondition(condition: .onQueue(.main))
        let pid = NSWorkspace.shared.frontmostApplication?.processIdentifier ?? 0
        if observedPID != pid {
            observedPID = pid
            focusNeedsActivation = true
        }
        verified.contextChanged()
        noteSelection()
    }
    func resetContext() {
        cancelPending()
        observedPID = nil
        refreshContext()
    }
    // Resolve a fresh source for every request. Re-enabling before selection
    // refreshes the input method's activation after the focused client changes.
    private func selectFresh(_ id: String) -> Bool {
        let filter = [kTISPropertyInputSourceID as String: id] as CFDictionary
        let sources = TISCreateInputSourceList(filter, true).takeRetainedValue() as! [TISInputSource]
        guard let source = sources.first(where: { Self.bool($0, kTISPropertyInputSourceIsSelectCapable) }) else { return false }
        guard TISEnableInputSource(source) == noErr else { return false }
        return TISSelectInputSource(source) == noErr
    }
    // HIToolbox must run on the main queue, never on the event-tap thread.
    // Selection starts immediately; only its verification is deferred.
    func requestToggle(allowed: @escaping () -> Bool = { true }, completion: @escaping (Bool) -> Void) {
        DispatchQueue.main.async { [weak self] in
            guard let self, allowed(), !IsSecureEventInputEnabled() else { completion(false); return }
            self.refreshContext()
            let id = self.verified.intendedSource ?? Self.currentID
            if !self.ready { self.prepare() }
            self.lock.lock()
            let target = Self.isKorean(id) ? self.english : self.korean
            self.lock.unlock()
            guard let target else { completion(false); return }
            // The TIS ID can update before the newly focused app has activated
            // its IME. Reassert once after the run loop settles, unless typing,
            // another switch, or another app has already superseded the request.
            let reassert = self.focusNeedsActivation
            self.focusNeedsActivation = false
            let pid = self.observedPID
            self.verified.request(target: Self.string(target, kTISPropertyInputSourceID), reassert: reassert) { success in
                if !success && self.observedPID == pid { self.focusNeedsActivation = true }
                completion(success)
            }
        }
    }
    var name: String {
        dispatchPrecondition(condition: .onQueue(.main))
        return Self.string(TISCopyCurrentKeyboardInputSource().takeRetainedValue(), kTISPropertyLocalizedName)
    }
}

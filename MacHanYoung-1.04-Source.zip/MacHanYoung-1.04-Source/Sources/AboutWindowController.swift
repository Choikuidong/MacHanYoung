import AppKit

/// Presentation only; independent of keyboard processing and user preferences.
final class AboutWindowController {
    private var window: NSWindow?

    func present() {
        if window == nil { window = makeWindow() }
        NSApp.activate(ignoringOtherApps: true)
        window?.center()
        window?.makeKeyAndOrderFront(nil)
    }

    @objc private func openWebsite() {
        NSWorkspace.shared.open(URL(string: "https://applecraft.kr/")!)
    }

    private func makeWindow() -> NSWindow {
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 440, height: 336),
                              styleMask: [.titled, .closable], backing: .buffered, defer: false)
        window.title = "맥한영에 관하여"
        window.isReleasedWhenClosed = false
        let root = window.contentView!
        func label(_ text: String, size: CGFloat, weight: NSFont.Weight = .regular,
                   color: NSColor = .labelColor, y: CGFloat, height: CGFloat) {
            let view = NSTextField(labelWithString: text)
            view.font = .systemFont(ofSize: size, weight: weight)
            view.textColor = color; view.alignment = .center
            view.frame = NSRect(x: 20, y: y, width: 400, height: height)
            root.addSubview(view)
        }
        label("맥한영", size: 31, weight: .bold, y: 272, height: 42)
        label("MacHanYoung", size: 17, y: 241, height: 27)
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
        label("버전 \(version)", size: 12, color: .secondaryLabelColor, y: 211, height: 22)
        let line = NSBox(frame: NSRect(x: 26, y: 188, width: 388, height: 1))
        line.boxType = .separator; root.addSubview(line)
        if let url = Bundle.main.url(forResource: "AppleCraftSymbol", withExtension: "png"),
           let image = NSImage(contentsOf: url) {
            let icon = NSImageView(frame: NSRect(x: 160, y: 129, width: 30, height: 36))
            icon.image = image; icon.imageScaling = .scaleProportionallyUpOrDown
            icon.setAccessibilityLabel("사과공방 로고")
            root.addSubview(icon)
        }
        let maker = NSTextField(labelWithString: "사과공방")
        maker.font = .systemFont(ofSize: 14, weight: .semibold)
        maker.frame = NSRect(x: 194, y: 146, width: 88, height: 20); root.addSubview(maker)
        let english = NSTextField(labelWithString: "Apple Craft")
        english.font = .systemFont(ofSize: 10)
        english.textColor = .secondaryLabelColor
        english.frame = NSRect(x: 194, y: 130, width: 88, height: 17); root.addSubview(english)
        label("개발자 최귀동", size: 12, y: 94, height: 22)
        label("© 2026 Apple Craft. All rights reserved.", size: 11,
              color: .secondaryLabelColor, y: 24, height: 20)
        let website = NSButton(title: "https://applecraft.kr/", target: self, action: #selector(openWebsite))
        website.isBordered = false
        website.font = .systemFont(ofSize: 12)
        website.contentTintColor = .linkColor
        website.frame = NSRect(x: 110, y: 57, width: 220, height: 24)
        website.toolTip = "사과공방 홈페이지 열기"
        website.setAccessibilityRole(.link)
        root.addSubview(website)
        return window
    }
}

import Foundation
import IOKit.hidsystem

struct KeyMapping: Codable, Equatable {
    var source: UInt64
    var destination: UInt64
    var dictionary: [String: UInt64] { ["HIDKeyboardModifierMappingSrc": source, "HIDKeyboardModifierMappingDst": destination] }
    static func rows(_ object: Any?) -> [KeyMapping] {
        (object as? [[String: NSNumber]] ?? []).compactMap {
            guard let src = $0["HIDKeyboardModifierMappingSrc"], let dst = $0["HIDKeyboardModifierMappingDst"] else { return nil }
            return KeyMapping(source: src.uint64Value, destination: dst.uint64Value)
        }
    }
}
struct HIDKeyboard {
    let service: IOHIDServiceClient
    let id: UInt64
    let name: String
    let builtIn: Bool
    let virtual: Bool
    var mapping: [KeyMapping] { KeyMapping.rows(IOHIDServiceClientCopyProperty(service, "UserKeyMapping" as CFString)) }
    func set(_ rows: [KeyMapping]) -> Bool {
        IOHIDServiceClientSetProperty(service, "UserKeyMapping" as CFString, rows.map(\.dictionary) as CFArray)
    }
}
struct SavedMapping: Codable {
    let id: UInt64
    let name: String
    let original: [KeyMapping]
    var applied: [KeyMapping]
}
final class NativeMappings {
    let url: URL
    var saved: [SavedMapping] = []
    var warnings: [String] = []
    init(url: URL) { self.url = url; Self.recover(url: url) }
    static let client = IOHIDEventSystemClientCreateSimpleClient(kCFAllocatorDefault)
    static func devices() -> [HIDKeyboard] {
        guard let services = IOHIDEventSystemClientCopyServices(client) as? [IOHIDServiceClient] else { return [] }
        return services.filter { IOHIDServiceClientConformsTo($0, 1, 6) != 0 }.compactMap { service in
            guard let number = IOHIDServiceClientGetRegistryID(service) as? NSNumber else { return nil }
            func property(_ key: String) -> Any? { IOHIDServiceClientCopyProperty(service, key as CFString) }
            let name = property("Product") as? String ?? "키보드"
            let manufacturer = property("Manufacturer") as? String ?? ""
            let virtual = (property("VirtualHIDDevice") as? NSNumber)?.boolValue == true || name.lowercased().contains("virtual") || manufacturer == "pqrs.org"
            return HIDKeyboard(service: service, id: number.uint64Value, name: name, builtIn: (property("Built-In") as? NSNumber)?.boolValue ?? false, virtual: virtual)
        }
    }
    static func desired(_ p: Preferences, inputReady: Bool) -> [KeyMapping] {
        guard p.enabled && inputReady else { return [] }
        let base: UInt64 = 0x700000000
        var pairs: [(UInt64, UInt64)] = []
        if p.swapModifiers { pairs += [(0xE2,0xE3),(0xE3,0xE2),(0xE7,0xE6),(0xE6,0xE7)] }
        if inputReady && p.ctrlShortcuts { pairs += [(0xE0,0x6D),(0xE4,0x6E)] } // F18/F19 device-marked Control
        if inputReady && p.languageSwitch {
            pairs += [(0xE6,0x6F),(0x90,0x6F)] // F20 device-marked language key
        }
        if inputReady && (p.rightControlHanja || p.consonantSymbols) { pairs += [(0xE4,0x6C)] } // F17 device-marked Hanja, independent of language switching
        if p.symbolShortcut { pairs += [(0xE3,0x6B),(0xE7,0x6A)] } // F16/F15 mark physical Windows keys
        var result: [KeyMapping] = []
        for (source, destination) in pairs {
            result.removeAll { $0.source == base | source }
            result.append(KeyMapping(source: base | source, destination: base | destination))
        }
        return result
    }
    static func merged(original: [KeyMapping], owned: [KeyMapping]) -> [KeyMapping] {
        let sources = Set(owned.map(\.source))
        return original.filter { !sources.contains($0.source) } + owned
    }
    func persist() throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(saved).write(to: url, options: .atomic)
    }
    func apply(_ p: Preferences, inputReady: Bool) throws -> [String] {
        let devices = Self.devices()
        let own = Self.desired(p, inputReady: inputReady)
        var names: [String] = []
        warnings = []
        saved.removeAll { record in !devices.contains { $0.id == record.id } }
        for device in devices where !device.virtual {
            let eligible = !p.externalOnly || !device.builtIn
            let desired = eligible ? own : []
            if let index = saved.firstIndex(where: { $0.id == device.id }) {
                let target = Self.merged(original: saved[index].original, owned: desired)
                if device.mapping != saved[index].applied && device.mapping != target {
                    throw failure("\(device.name)의 키 설정이 다른 앱에서 변경되었습니다. 종료 후 다시 실행하세요.")
                }
                if device.mapping != target {
                    saved[index].applied = target; try persist() // journal BEFORE mutation
                    if !device.set(target) || device.mapping != target {
                        _ = device.set(saved[index].original)
                        if device.mapping == saved[index].original { saved.remove(at: index); try persist() }
                        warnings.append("\(device.name): 매핑 지원 안 됨"); continue
                    }
                }
            } else if !desired.isEmpty {
                let original = device.mapping
                let target = Self.merged(original: original, owned: desired)
                saved.append(SavedMapping(id: device.id, name: device.name, original: original, applied: target)); try persist()
                if !device.set(target) || device.mapping != target {
                    _ = device.set(original)
                    if device.mapping == original { saved.removeAll { $0.id == device.id }; try persist() }
                    warnings.append("\(device.name): 매핑 지원 안 됨"); continue
                }
            }
            if eligible && !desired.isEmpty { names.append(device.name) }
        }
        return names
    }
    func failure(_ text: String) -> NSError { NSError(domain: "WinKeys", code: 2, userInfo: [NSLocalizedDescriptionKey: text]) }
    @discardableResult func restore() -> Bool {
        var unresolved: [SavedMapping] = []
        guard IOHIDEventSystemClientCopyServices(Self.client) != nil else { return saved.isEmpty }
        for device in Self.devices() {
            if let record = saved.first(where: { $0.id == device.id }), device.mapping == record.applied {
                if !device.set(record.original) || device.mapping != record.original { unresolved.append(record) }
            }
        }
        saved = unresolved; try? persist()
        return unresolved.isEmpty
    }
    static func recover(url: URL) {
        guard let data = try? Data(contentsOf: url), let saved = try? JSONDecoder().decode([SavedMapping].self, from: data), !saved.isEmpty else { return }
        guard IOHIDEventSystemClientCopyServices(client) != nil else { return } // Keep journal if HID service access is unavailable.
        var unresolved: [SavedMapping] = []
        for device in devices() {
            if let record = saved.first(where: { $0.id == device.id }), device.mapping == record.applied {
                if !device.set(record.original) || device.mapping != record.original { unresolved.append(record) }
            }
        }
        try? JSONEncoder().encode(unresolved).write(to: url, options: .atomic)
    }
}

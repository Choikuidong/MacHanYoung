import Foundation

struct Preferences: Codable {
    var automaticUpdates = true
    var symbolShortcut = true
    var consonantSymbols = true
    var swapModifiers = true
    var ctrlShortcuts = true
    var languageSwitch = true
    var externalOnly = true
    var enabled = true
    var terminalExceptions = true
    var rightControlHanja = true
    var showLanguagePopup = true
    var startAtLogin = true
    var reverseMouseScroll = false
    var reverseTrackpadScroll = false
    init() {}
    enum CodingKeys: String, CodingKey {
        case automaticUpdates, symbolShortcut, consonantSymbols, reverseMouseScroll, reverseTrackpadScroll, swapModifiers, ctrlShortcuts, languageSwitch, externalOnly, enabled, terminalExceptions, rightControlHanja, showLanguagePopup, startAtLogin
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        automaticUpdates = try c.decodeIfPresent(Bool.self, forKey: .automaticUpdates) ?? true
        symbolShortcut = try c.decodeIfPresent(Bool.self, forKey: .symbolShortcut) ?? true
        consonantSymbols = try c.decodeIfPresent(Bool.self, forKey: .consonantSymbols) ?? true
        reverseMouseScroll = try c.decodeIfPresent(Bool.self, forKey: .reverseMouseScroll) ?? false
        reverseTrackpadScroll = try c.decodeIfPresent(Bool.self, forKey: .reverseTrackpadScroll) ?? false
        swapModifiers = try c.decodeIfPresent(Bool.self, forKey: .swapModifiers) ?? true
        ctrlShortcuts = try c.decodeIfPresent(Bool.self, forKey: .ctrlShortcuts) ?? true
        languageSwitch = try c.decodeIfPresent(Bool.self, forKey: .languageSwitch) ?? true
        externalOnly = try c.decodeIfPresent(Bool.self, forKey: .externalOnly) ?? true
        enabled = try c.decodeIfPresent(Bool.self, forKey: .enabled) ?? true
        terminalExceptions = try c.decodeIfPresent(Bool.self, forKey: .terminalExceptions) ?? true
        // Hanja replaces the former language-switch option and starts enabled.
        // Existing choices for every other feature remain unchanged.
        rightControlHanja = try c.decodeIfPresent(Bool.self, forKey: .rightControlHanja) ?? true
        showLanguagePopup = try c.decodeIfPresent(Bool.self, forKey: .showLanguagePopup) ?? true
        startAtLogin = try c.decodeIfPresent(Bool.self, forKey: .startAtLogin) ?? true
    }
}

import AppKit

enum AppInstallation {
    static func isInstalled(_ url: URL) -> Bool {
        let parent = url.standardizedFileURL.deletingLastPathComponent().path
        return parent == "/Applications" || parent == NSHomeDirectory() + "/Applications"
    }

    // Return before creating the engine or registering login items when opened
    // from a disk image, Downloads, or an App Translocation path.
    static func prepare() -> Bool {
        let source = Bundle.main.bundleURL
        guard !isInstalled(source) else { return true }
        let fm = FileManager.default
        let folder = fm.isWritableFile(atPath: "/Applications")
            ? URL(fileURLWithPath: "/Applications")
            : fm.homeDirectoryForCurrentUser.appendingPathComponent("Applications")
        // Preserve an existing installation path and its login registration.
        let legacy = folder.appendingPathComponent("WinKeys.app")
        let target = Bundle(url: legacy)?.bundleIdentifier == Bundle.main.bundleIdentifier
            ? legacy : folder.appendingPathComponent("맥한영.app")
        let currentBuild = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0"
        if let installed = Bundle(url: target), installed.bundleIdentifier == Bundle.main.bundleIdentifier,
           let version = installed.object(forInfoDictionaryKey: "CFBundleVersion") as? String,
           version.compare(currentBuild, options: .numeric) != .orderedAscending {
            launch(target)
            return false
        }
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "맥한영을 응용 프로그램에 설치합니다"
        alert.informativeText = "설치 후 자동으로 실행합니다. 처음 한 번 키보드 접근 권한을 허용하면 다음 로그인부터 자동으로 실행됩니다."
        alert.addButton(withTitle: "설치하고 시작")
        alert.addButton(withTitle: "취소")
        guard alert.runModal() == .alertFirstButtonReturn else { NSApp.terminate(nil); return false }
        let running = NSWorkspace.shared.runningApplications.filter {
            $0.bundleIdentifier == Bundle.main.bundleIdentifier && $0.processIdentifier != ProcessInfo.processInfo.processIdentifier
        }
        for app in running { _ = app.terminate() }
        let deadline = Date().addingTimeInterval(3)
        while running.contains(where: { !$0.isTerminated }) && Date() < deadline {
            RunLoop.current.run(until: Date().addingTimeInterval(0.05))
        }
        guard !running.contains(where: { !$0.isTerminated }) else {
            fail("실행 중인 맥한영을 종료한 뒤 다시 설치해 주세요."); return false
        }
        let staging = folder.appendingPathComponent(".WinKeys-install-" + UUID().uuidString + ".app")
        var backup: URL?
        do {
            try fm.createDirectory(at: folder, withIntermediateDirectories: true)
            try fm.copyItem(at: source, to: staging)
            if fm.fileExists(atPath: target.path) {
                let backups = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("WinKeys/Backups")
                try fm.createDirectory(at: backups, withIntermediateDirectories: true)
                let previous = backups.appendingPathComponent("WinKeys-" + UUID().uuidString + ".app")
                try fm.moveItem(at: target, to: previous)
                backup = previous
            }
            try fm.moveItem(at: staging, to: target)
            launch(target)
        } catch {
            if let backup, !fm.fileExists(atPath: target.path) { try? fm.moveItem(at: backup, to: target) }
            try? fm.removeItem(at: staging)
            fail("설치하지 못했습니다. 맥한영을 응용 프로그램 폴더로 직접 옮긴 뒤 실행해 주세요.\n\(error.localizedDescription)")
        }
        return false
    }

    private static func launch(_ target: URL) {
        let configuration = NSWorkspace.OpenConfiguration()
        configuration.activates = true
        // The DMG process has the same bundle ID. Without this, LaunchServices
        // can return that process instead of starting the installed executable.
        configuration.createsNewApplicationInstance = true
        NSWorkspace.shared.openApplication(at: target, configuration: configuration) { _, error in
            DispatchQueue.main.async {
                if let error { fail(error.localizedDescription) }
                else { exit(0) }
            }
        }
    }
    private static func fail(_ message: String) {
        let alert = NSAlert(); alert.messageText = "설치를 완료하지 못했습니다"
        alert.informativeText = message; alert.runModal(); NSApp.terminate(nil)
    }
}

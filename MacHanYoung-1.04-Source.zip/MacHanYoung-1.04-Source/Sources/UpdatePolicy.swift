import Foundation

struct AppVersion: Comparable, Equatable {
    let parts: [Int]
    init?(_ raw: String) {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.hasPrefix("v") || text.hasPrefix("V") { text.removeFirst() }
        let chunks = text.split(separator: ".", omittingEmptySubsequences: false)
        guard (2...3).contains(chunks.count), chunks.allSatisfy({ !$0.isEmpty && $0.count <= 6 && $0.utf8.allSatisfy { (48...57).contains($0) } }) else { return nil }
        parts = chunks.map { Int($0)! } + Array(repeating: 0, count: 3-chunks.count)
    }
    static func < (lhs: Self, rhs: Self) -> Bool { lhs.parts.lexicographicallyPrecedes(rhs.parts) }
}

enum UpdateError: Error, LocalizedError, Equatable {
    case network, rateLimited, throttled, noRelease, invalidResponse, server
    var errorDescription: String? {
        switch self {
        case .network: return "인터넷 연결을 확인한 뒤 다시 시도해 주세요."
        case .throttled: return "방금 업데이트를 확인했습니다. 1분 뒤에 다시 확인할 수 있습니다."
        case .rateLimited: return "GitHub의 요청 한도에 도달했습니다. 잠시 후 다시 확인해 주세요."
        case .noRelease: return "아직 공개된 정식 릴리스가 없습니다. 사과공방 홈페이지에서 배포 안내를 확인하세요."
        case .invalidResponse: return "업데이트 정보를 확인하지 못했습니다. 사과공방 홈페이지에서 배포 안내를 확인해 주세요."
        case .server: return "GitHub에 일시적으로 연결할 수 없습니다. 잠시 후 다시 확인해 주세요."
        }
    }
}

struct PublishedRelease: Decodable, Equatable {
    struct Asset: Decodable, Equatable { let name: String; let state: String }
    let tag_name: String
    let name: String?
    let body: String?
    let html_url: String
    let draft: Bool
    let prerelease: Bool
    let assets: [Asset]
    var version: String { String(tag_name.drop(while: { $0 == "v" || $0 == "V" })) }
    var notes: String { String((body ?? "변경 내용은 사과공방 홈페이지에서 확인하세요.").prefix(16000)) }
    var isInstallable: Bool {
        guard !draft, !prerelease, AppVersion(tag_name) != nil,
              let url = URL(string: html_url), url.scheme == "https", url.host?.lowercased() == "github.com",
              url.user == nil, url.password == nil, url.port == nil,
              url.path.hasPrefix("/Choikuidong/MacHanYoung/releases/tag/") else { return false }
        return assets.contains { $0.state == "uploaded" && $0.name.lowercased().hasPrefix("machanyoung-") && $0.name.lowercased().hasSuffix(".dmg") }
    }
    static func decode(_ data: Data, status: Int) -> Result<PublishedRelease, UpdateError> {
        if status == 403 || status == 429 { return .failure(.rateLimited) }
        if status == 404 { return .failure(.noRelease) }
        guard status == 200 else { return .failure(.server) }
        guard data.count <= 2_000_000, let release = try? JSONDecoder().decode(Self.self, from: data), release.isInstallable else { return .failure(.invalidResponse) }
        return .success(release)
    }
}

/// Version comparison uses numeric components (1.09 < 1.10); never floating point.
final class UpdateChecker {
    static let endpoint = URL(string: "https://api.github.com/repos/Choikuidong/MacHanYoung/releases/latest")!
    // All download/help actions go to the maker's site, never a GitHub asset.
    static let homepage = URL(string: "https://applecraft.kr/?view=programs#app-machanyoung")!
    typealias Fetch = (@escaping (Result<PublishedRelease, UpdateError>) -> Void) -> Void
    enum Notice: Equatable {
        case available(PublishedRelease)
        case current(latest: String)
        case failure(UpdateError)
        case checking
    }
    var changed: (() -> Void)?
    var show: ((Notice, Bool) -> Void)?
    private(set) var available: PublishedRelease?
    private(set) var checking = false
    private var manualPending = false
    private var autoEnabled = true
    private let currentVersion: AppVersion?
    private let defaults: UserDefaults
    private let now: () -> Date
    private let fetch: Fetch
    private var lastManual: Date?
    private var timer: Timer?
    private var stopped = false
    init(version: String, defaults: UserDefaults = .standard, now: @escaping () -> Date = Date.init, fetch: @escaping Fetch = UpdateChecker.fetchLatest) {
        currentVersion = AppVersion(version); self.defaults = defaults; self.now = now; self.fetch = fetch
    }
    var menuTitle: String {
        if checking { return "업데이트 확인 중…" }
        if let available { return "업데이트 확인… (\(available.version) 사용 가능)" }
        return "업데이트 확인…"
    }
    func start(enabled: Bool) {
        stopped = false; autoEnabled = enabled
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 3600, repeats: true) { [weak self] _ in self?.check(manual: false) }
        check(manual: false)
    }
    func setAutomatic(_ enabled: Bool) {
        autoEnabled = enabled
        if enabled { check(manual: false) }
    }
    func stop() { stopped = true; timer?.invalidate(); timer = nil; show = nil; changed = nil }
    func check(manual: Bool) {
        guard !stopped else { return }
        if !manual && !autoEnabled { return }
        if manual, let available { show?(.available(available), true); return }
        if checking {
            if manual { manualPending = true; show?(.checking, true) }
            return
        }
        let time = now()
        if manual, let lastManual, time.timeIntervalSince(lastManual) < 60 {
            show?(.failure(.throttled), true); return
        }
        if !manual, let attempt = defaults.object(forKey: "updateLastAttempt") as? Date {
            let elapsed = time.timeIntervalSince(attempt)
            if elapsed >= 0 && elapsed < 24*3600 { return }
        }
        guard currentVersion != nil else { if manual { show?(.failure(.invalidResponse), true) }; return }
        if manual { lastManual = time }
        checking = true; manualPending = manual
        defaults.set(time, forKey: "updateLastAttempt")
        changed?()
        if manual { show?(.checking, true) }
        fetch { [weak self] result in self?.receive(result) }
    }
    private func receive(_ result: Result<PublishedRelease, UpdateError>) {
        guard !stopped else { return }
        checking = false
        let manual = manualPending; manualPending = false
        defer { changed?() }
        switch result {
        case .failure(let error): if manual { show?(.failure(error), true) }
        case .success(let release):
            guard release.isInstallable, let remote = AppVersion(release.tag_name), let currentVersion else { if manual { show?(.failure(.invalidResponse), true) }; return }
            defaults.set(now(), forKey: "updateLastSuccess")
            if remote > currentVersion {
                available = release
                let alreadyShown = defaults.string(forKey: "updateNotifiedVersion") == release.tag_name
                if manual || (autoEnabled && !alreadyShown) {
                    defaults.set(release.tag_name, forKey: "updateNotifiedVersion")
                    show?(.available(release), manual)
                }
            } else {
                available = nil
                if manual { show?(.current(latest: release.version), true) }
            }
        }
    }
    static func fetchLatest(completion: @escaping (Result<PublishedRelease, UpdateError>) -> Void) {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15; configuration.timeoutIntervalForResource = 25
        configuration.httpShouldSetCookies = false; configuration.httpCookieStorage = nil; configuration.urlCache = nil
        let session = URLSession(configuration: configuration)
        var request = URLRequest(url: endpoint, cachePolicy: .reloadIgnoringLocalCacheData)
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("MacHanYoung-UpdateChecker", forHTTPHeaderField: "User-Agent")
        session.dataTask(with: request) { data, response, error in
            defer { session.finishTasksAndInvalidate() }
            let result: Result<PublishedRelease, UpdateError>
            if error != nil { result = .failure(.network) }
            else if let response = response as? HTTPURLResponse, response.url?.host == "api.github.com", let data {
                result = PublishedRelease.decode(data, status: response.statusCode)
            } else { result = .failure(.invalidResponse) }
            DispatchQueue.main.async { completion(result) }
        }.resume()
    }
}

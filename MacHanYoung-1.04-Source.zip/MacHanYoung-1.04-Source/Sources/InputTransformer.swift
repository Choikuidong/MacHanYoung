import AppKit

struct InputTransformer {
    static let symbolShortcutKeys: Set<Int> = [41, 47] // semicolon and period
    static let tag: Int64 = 0x57494E4B455953
    static let shortcuts: Set<Int> = [0,1,2,3,6,7,8,9,12,13,17,31,35,45]
    var controls = Set<Int>()
    var shortcutsHeld = Set<Int>()
    var nativeControlHeld = false

    mutating func control(_ key: Int, down: Bool, flags: CGEventFlags) -> CGEventFlags {
        if down { controls.insert(key) } else { controls.remove(key) }
        var result = CGEventFlags(rawValue: flags.rawValue & ~UInt64(0x2001))
        result.remove(.maskControl)
        if !controls.isEmpty || nativeControlHeld { result.insert(.maskControl) }
        return result
    }
    mutating func flags(_ original: CGEventFlags, key: Int, down: Bool, terminal: Bool) -> CGEventFlags {
        var result = original
        if !controls.isEmpty { result.insert(.maskControl) }
        let convert = down
            ? (!controls.isEmpty && !terminal && Self.shortcuts.contains(key) && !result.contains(.maskAlternate))
            : shortcutsHeld.contains(key)
        if convert {
            result = CGEventFlags(rawValue: result.rawValue & ~UInt64(0x2001))
            result.remove(.maskControl); result.insert(.maskCommand)
            if down { shortcutsHeld.insert(key) } else { shortcutsHeld.remove(key) }
        }
        return result
    }
    static func languagePress(type: CGEventType, autorepeat: Int64) -> Bool {
        // A fresh hardware keyDown remains valid even if the previous keyUp
        // was lost during an app change, sleep, or secure-input transition.
        type == .keyDown && autorepeat == 0
    }
    static func hanjaEvent(_ event: CGEvent) -> CGEvent? {
        if event.type == .keyDown && event.getIntegerValueField(.keyboardEventAutorepeat) != 0 { return nil }
        event.setIntegerValueField(.keyboardEventKeycode, value: 36)
        event.flags = .maskAlternate
        return event
    }
}

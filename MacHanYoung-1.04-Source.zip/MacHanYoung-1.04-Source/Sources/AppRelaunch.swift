import AppKit

enum AppRelaunch {
    /// Start a waiting helper before exit, so duplicate-instance protection never
    /// redirects the launch back to the process that is shutting down.
    static func schedule() throws {
        guard let executable = Bundle.main.executableURL else {
            throw NSError(domain: "MacHanYoung.Relaunch", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "앱 실행 파일을 찾지 못했습니다."])
        }
        let helper = Process()
        helper.executableURL = executable
        helper.arguments = ["--relaunch-after", String(ProcessInfo.processInfo.processIdentifier), Bundle.main.bundlePath]
        helper.standardOutput = FileHandle.nullDevice
        helper.standardError = FileHandle.nullDevice
        try helper.run()
    }
    static func runHelper(parent: Int32, path: String) {
        let deadline = Date().addingTimeInterval(30)
        while kill(parent, 0) == 0 {
            guard Date() < deadline else { return }
            Thread.sleep(forTimeInterval: 0.1)
        }
        let configuration = NSWorkspace.OpenConfiguration()
        configuration.activates = true
        configuration.createsNewApplicationInstance = true
        var finished = false
        NSWorkspace.shared.openApplication(at: URL(fileURLWithPath: path), configuration: configuration) { _, error in
            if let error { NSLog("MacHanYoung relaunch failed: %@", error.localizedDescription) }
            DispatchQueue.main.async { finished = true }
        }
        let launchDeadline = Date().addingTimeInterval(15)
        while !finished && Date() < launchDeadline { RunLoop.current.run(until: Date().addingTimeInterval(0.1)) }
    }
}
